import React from 'react';
import { Navigate  } from "react-router-dom";
function Profilenew ({ authorized }) {
    if(!authorized){

        return <Navigate  to="/Login" />;
     }
  
    return (
            <div className='Login'>
            <h1>mjbskvb kdb sdbn</h1>;
            </div>
 
    );
}
  
export default Profilenew;