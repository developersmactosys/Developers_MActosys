// old work 

// import React from 'react';
// import { Link } from 'react-router-dom';
// import  Axios  from 'axios';
// import { useState } from "react";
// function AddProduct () {
// 	const url = "https://eventneedz.com/api/product"
// 	const[data,setData]=useState({
// 		name: "",
// 		quantity:"",
// 		description: "",
// 		seoName: "",
// 		image:"",
// 		campaignBanner:"",
// 		mobiledescription: "",
// 	})
// 	//const [name, setName] = useState("");
//  // const [quantity, setQuantity] = useState("");
//  // const [description, setDescription] = useState("");
//  // const [seoName, setSeoName] = useState("");
//  // const [image, setImage] = useState("");
//  // const [campaignBanner, setCampaignBanner] = useState("");
//  // const [mobiledescription, setMobiledescription] = useState("");
//  function submit(e){
// 	e.preventDefault();
// 	Axios.post(url,{

// 		name: data.name,
// 		quantity:data.quantity,
// 		description: data.description,
// 		seoName: data.seoName,
// 		image:data.image,
// 		campaignBanner:data.campaignBanner,
// 		mobiledescription: data.mobiledescription
// 	})
// 	.then(res =>{
// 		console.log(res.data)
// 	})
//  }
// 	function handle(e){
// 		const newdata={...data}
// 		newdata[e.target.id]=e.target.value
// 		setData(newdata)
// 		console.log(newdata)

// 	}
 
  
//     return <>
//         <div className="content-header">
// 			<div className="d-flex align-items-center">
// 				<div className="mr-auto">
// 					<div className="d-inline-block align-items-center">
// 						<nav>
// 						<ol className="breadcrumb">
// 								<li className="breadcrumb-item"><Link to="/"><i className="fa fa-home"></i> Dashboard</Link></li>
// 								<li className="breadcrumb-item"><Link to="/Product"> Product </Link></li>
// 								<li className="breadcrumb-item"> Add Product  </li>
// 							</ol>
// 						</nav>
// 					</div>
// 				</div>
				
// 			</div>
// 		</div>
//         <section className="content">
// 		  <div className="row">
// 		<div className="col-lg-12 col-12">
//         <div className="box">
						
// 						<form  onSubmit={(e)=> submit(e)}>
// 							<div className="box-body">
// 								<h4 className="mt-0 mb-20"> Product Info:</h4>
// 								<div className="form-group">
// 									<label> Name:</label>
// 									<input type="text" value={data.name} id='name' className="form-control" placeholder="Product Name" onChange={(e) => handle(e)}/>
// 								</div>
// 								<div className="form-group">
// 									<label>  Description:</label>
// 									<textarea className="form-control" id='description' value={data.description} placeholder="Product Description" onChange={(e) => handle(e)}></textarea>
// 								</div>
// 								<div className="form-group">
// 									<label for="tags">Quantity </label>
// 									<input type="text" value={data.quantity} id='quantity' className="form-control" placeholder="Quantity" onChange={(e) => handle(e)}/>
// 								</div>
// 								<div className='row'>
// 									<div className='col-md-12'>
// 										<div className='row'>
// 											<div className='col-md-6'>
// 												<div className="form-group">
// 													<label for="tags">SEO Name </label>
// 													<input type="text" value={data.seoName} id='seoName' className="form-control" placeholder="SEO Name" onChange={(e) => handle(e)}/>
// 												</div>
// 											</div>
// 											<div className='col-md-6'>
// 												<div className="form-group">
// 													<label for="tags">Mobile No</label>
// 													<input type="text" value={data.mobiledescription} id='mobiledescription' className="form-control" placeholder="Mobile No" onChange={(e) => handle(e)}/>
// 												</div>
// 											</div>
											
// 										</div>
										
// 									</div>
									
// 								</div>
								
								
// 								<div className="form-group">
// 									<label>Image:</label>
// 									<div className="input-group">
// 										<div className="input-group-prepend">
// 											<span className="input-group-text" id="inputGroupFileAddon01">
// 											Upload
// 											</span>
// 										</div>
// 										<div className="custom-file">
// 											<input
// 											type="file" value={data.image}
// 											className="custom-file-input"
// 											id="image"
// 											onChange={(e) => handle(e)}
// 											/>
// 											<label className="custom-file-label" htmlFor="inputGroupFile01">
// 											Choose file
// 											</label>
// 										</div>
// 										</div>
// 								</div>
// 								<div className="form-group">
// 									<label>Banner:</label>
// 									<div className="input-group">
// 										<div className="input-group-prepend">
// 											<span className="input-group-text" id="inputGroupFileAddon0">
// 											Upload
// 											</span>
// 										</div>
// 										<div className="custom-file">
// 											<input
// 											type="file" value={data.campaignBanner}
// 											className="custom-file-input"
// 											id="campaignBanner" 
// 											onChange={(e) => handle(e)}
// 											/>
// 											<label className="custom-file-label" htmlFor="inputGroupFile01">
// 											Choose file
// 											</label>
// 										</div>
// 										</div>
// 								</div> 
								
// 							</div>
							
// 							<div className="box-footer">
// 								<button type="button" className="btn btn-warning" style={{marginRight:"10px"}}>Reset</button>
// 								<button type="submit" className="btn  btn-primary">Add Product</button>
// 							</div>
// 						</form>
// 					  </div>
// 				</div>
//                 </div>
//                 </section>
		
//     </>
// }
// export default AddProduct;

// new work


// const Category = () => {
// 	const [users, setUsers] = useState([]);
// 	const getUsers = async () => {
// 		const response = await fetch('https://www.eventneedz.com/api/events/category');
		
// 		setUsers(await response.json());
// 		$("#lodderGet").css("display", "none");
// 		//console.log(data);

// 	}
// 	useEffect(() => {
// 		getUsers();
// 	},[]);
// 	function viewOpration(id){
// 			alert(id)
// 	}
//     return (
//         <>
// 		 <div className="content-header">
//                 <div className="d-flex align-items-center">
//                     <div className="mr-auto">
//                         <div className="d-inline-block align-items-center">
//                             <nav>
//                                  <ol className="breadcrumb">
//                                     <li className="breadcrumb-item"><Link to="/"><i className="fa fa-home"></i> Dashboard</Link></li>
//                                     <li className="breadcrumb-item">Category </li>
//                                 </ol>
//                             </nav>
//                         </div>
//                     </div>
//                     <Link to="/AddCategory" className='btn btn-primary'> <i class="fa fa-plus-circle"></i> Add Category </Link>
//                 </div>
// 		</div>
// 		<section className="content">
// 		  <div className="row">
//           <div className="col-12">
// 			  <div className="box">
// 				<div className="box-header with-border">
// 				  <h4 className="box-title">Category List <Spinner animation="grow"  variant="info" size="2px" style={{ display: "block" }} id="lodderGet" /> </h4>
// 				  <div className="box-controls pull-right">
// 					<div className="lookup lookup-circle lookup-right">
// 					  <input type="text" name="s" />
// 					</div>
// 				  </div>
// 				</div>
// 				<div className="box-body no-padding">
// 					<div className="table-responsive">
// 					  <table className="table table-hover">
// 						<tbody><tr>
// 						  <th>ID</th>
						
// 						  <th>Name</th>
// 						  <th>PHOTO</th>
// 						  <th>Total Product</th>
// 						  <th>Status</th>
//                           <th>ACTIONS</th>
// 						</tr>
// 						{
// 							users.map((curElem) =>{
// 						console.log(curElem);
// 								return(
// 								<tr>
// 									<td>{curElem.id}</td>
// 									<td>{curElem.name}</td>										
// 									<td><img src={'https://eventneedz.com'+curElem.image} width={'100px'} alt=''/></td>
// 									<td>{curElem.OGDescription}</td>
// 									<td>{curElem.status}</td>
// 									<td>
// 										<Link to={"/CategoryView/"+curElem.id} className='badge badge-pill badge-warning' ><i className='fa fa-eye'></i></Link>
// 										<Link to={"/UpdateCategory/"+curElem.id} className='badge badge-pill badge-warning' ><i class="fa fa-pencil-square-o" aria-hidden="true"></i></Link>
// 										 <Link to={"/CategoryView/"+curElem.id} className='badge badge-pill badge-danger'><i className='fa fa-trash'></i></Link></td>
// 								</tr>
// 								)

// 							})
// 						}
						
// 					  </tbody></table>
// 					</div>
// 				</div>
// 			  </div>
// 			</div>
//             </div>
//         </section>
        
//     </>

//     )
// }




import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom';
import alertify from 'alertifyjs';
import 'alertifyjs/build/css/alertify.css';
import AddCategory from '../Category/AddCategory';
import { Alert } from 'bootstrap';
const axios = require('axios');




function AddProduct() {

	const [file, setFile] = useState({
		file: [],
		filepreview: null
	});


	const [product_amount, SetProduct_amount] = useState("");
	const [product_tagline, SetProduct_tagline] = useState("");
	const [product_slide_image1, SetProduct_slide_image1] = useState("");
	const [product_slide_image2, SetProduct_slide_image2] = useState("");
	const [product_slide_image3, SetProduct_slide_image3] = useState("");
	const [product_slide_image4, SetProduct_slide_image4] = useState("");
	const [selectList, SetSelectList] = useState("");
	const [product_vendor, setProduct_vendor] = useState("");
	const [ProductType, SetProductType] = useState("");
	const [product_flat_price, SetProduct_flat_price] = useState("");
	const [product_offcer, SetProduct_offcer] = useState("");
	const [product_despoit, SetProduct_despoit] = useState("");
	const [product_valid_offer, Setproduct_valid_offer] = useState("");
	const [product_stock_info, Setproduct_stock_info] = useState("");
	const [product_rating, SetProduct_rating] = useState("");
	const [product_cover_image, SetProduct_cover_image] = useState("");

	const [product_name, SetProduct_name] = useState("");
	const [category_id, setCategory_id] = useState("");
	const [product_quantity, setProduct_quantity] = useState("");
	const [product_description, SetProduct_description] = useState("");

	const [category, setCategory] = useState([]);

	useEffect(() => {
		getcategory();
	}, []);

	const getcategory = () => {


		// fetch('http://192.168.1.22:4260/category_list').
		fetch('http://34.125.20.72:4260/category_list').
			then((result) => {
				result.json().
					then((resp) => {
						setCategory(resp.data)
						console.log("", resp.data)
					})
			});

		$("#lodderGet").css("display", "none");

	}

	const handleFileChange = (event) => {
		setFile({
			...file,
			file: event.target.files[0],
			filepreview: URL.revokeObjectURL(event.target.files[0]),


		})
	}
	// const handleFileChange = (event) => {
	// 	SetProduct_cover_image(e.target.files);
	// 	console.log(product_cover_image)
	// }

	// const handleSubmit = (e) => {
	// 	e.preDefault();
	// 	const data = new FormData();
	// 	for (var x = 0; x < product_cover_image.length; x++) {
	// 		data.append('product_cover_image', product_cover_image[x])
	// 	}
	// 	axios.post("http://34.125.20.72:3000/MobileServices/uploads", data)
	// 		.then(res => {
	// 			console.log(res.statusText)
	// 		})
	// }


	async function addinfo(e) {

		e.preventDefault()

		let item = { product_vendor, category_id, product_slide_image1, product_slide_image2, product_slide_image3, product_slide_image4, selectList, product_cover_image, product_offcer, product_rating, product_stock_info, product_valid_offer, product_despoit, product_flat_price, ProductType, product_name, product_quantity, product_description, product_tagline, product_amount }


		let result = await fetch("http://34.125.20.72:4260/add_product_admin", {
		// let result = await fetch("http://34.125.20.72:4260/movetoupload", {
			method: 'POST',
			headers: {
				"Content-Type": "application/json",
				"Accept": "application/json"
			},
			body: JSON.stringify(item)
		})
		result = await result.json();


		if (result.id) {
			alertify.success('Your Product Successfull Added Please wait for verification ');
		}

		const FormData = new FormData();
		FormData.append('avatar', product_cover_image.file);

		axios.post("http://34.125.20.72:3000/movetoupload", FormData, {
			headers: { "content-Type": "multipart/form-data" }
		})
			.then(res => {
				console.log(res)
			})


		SetProduct_amount("");
		SetProduct_tagline("");
		SetProduct_name("");
		setProduct_vendor("");
		SetProductType("");
		SetProduct_flat_price("");
		SetProduct_offcer("");
		SetProduct_despoit("");
		Setproduct_stock_info("");
		SetProduct_rating("");

		SetProduct_cover_image("");
		SetProduct_slide_image1("");
		SetProduct_slide_image2("");
		SetProduct_slide_image3("");
		SetProduct_slide_image4("");

		setCategory_id("")
		SetProduct_name("")
		Setproduct_valid_offer("")
		setProduct_quantity("");
		SetProduct_description("");
		SetSelectList("");






	}


	return <>
		<div className="content-header">
			<div className="d-flex align-items-center">
				<div className="mr-auto">
					<div className="d-inline-block align-items-center">
						<nav>
							<ol className="breadcrumb">
								<li className="breadcrumb-item"><Link to="/"><i className="fa fa-home"></i> Dashboard</Link></li>
								<li className="breadcrumb-item"><Link to="/product"> Product </Link></li>
								<li className="breadcrumb-item">Add Product</li>
							</ol>
						</nav>
					</div>
				</div>

			</div>
		</div>
		<section className="content">
			<form onSubmit={(e) => addinfo(e)} enctype="multipart/form-data">
				<div className="row">
					<div className="col-lg-12 col-12">
						<div className="box">
							<div className="box-body">
								<h4 className="mt-0 mb-20">Add Product :</h4>
								<div className="form-group" enctype="multipart/form-data">
									<label> Vendore Name: </label>
									<select name="productlist" value={product_vendor} className="form-control" onChange={(e) => setProduct_vendor(e.target.value)} placeholder='Vendor Name' required="Name required">


										<option value="Admin"> Admin </option>
									</select>
								</div>

								<div className="form-group">
									<div className="form-group">
										<label> App Type: </label>
										<select name="selectList" value={selectList} className="form-control" onChange={(e) => SetSelectList(e.target.value)} placeholder='App Type' required="required">

											<option value="SELL"> Sell </option>
											<option value="RENT"> rent </option>

										</select>
									</div>
									<div className="form-group">
										<label> category: </label>
										<select name="selectList" value={category_id} className="form-control" onChange={(e) => setCategory_id(e.target.value)} placeholder='Category' required >

											{category && category.map((data, index) => {
												return (

													<option value={data.category.id} >{data.category.name} </option>
												)
											})}

										</select>
									</div>

								</div>
								{/* <div className="form-group">
								<label> Vendore Name:</label>
								<input type="text" value={product_vendor} onChange={(e) => setProduct_vendor(e.target.value)} placeholder=' Product_Vendore_Name' className='form-control' required="required" />
							</div> */}
								{/*<div className="form-group" style={display='none'}>
								<label> Vendore id:</label>
								<input type="text" value={product_vendor_id} onChange={(e) => SetProduct_vendor_id(e.target.value)} placeholder=' Product_Vendore_Name' className='form-control' required="required" />
							</div> */}
								<div className="form-group">
									<label> Product Name:</label>
									<input type="text" value={product_name} onChange={(e) => SetProduct_name(e.target.value)} placeholder=' Product Name' className='form-control' required="required" />
								</div>
								<div className="form-group">
									<label> Product Type:</label>
									<select name="selectList" value={ProductType} className="form-control" onChange={(e) => SetProductType(e.target.value)} placeholder='Contact Name' required="required">

										<option value={"FEATURE"}> Feature </option>
										<option value={"RECOMMENDED"}> Recommended </option>
									</select>

								</div>
								<div className="form-group">
									<label> Product Tagline:</label>
									<input type="text" value={product_tagline} onChange={(e) => SetProduct_tagline(e.target.value)} placeholder=' Product Tagline' className='form-control' required="required" />
								</div>
								<div className="form-group">
									<label> Product Flat Price: </label>
									<input type="number" name="quantity" value={product_flat_price} onChange={(e) => SetProduct_flat_price(e.target.value)} placeholder=' ProductFlate Price' className='form-control' required="required" />
								</div>
								<div className="form-group">
									<label> Product Amount: </label>
									<input type="number" name="quantity" value={product_amount} onChange={(e) => SetProduct_amount(e.target.value)} placeholder=' Product Flate Price' className='form-control' required="required" />
								</div>
								<div className="form-group">
									<label> Product Offer:</label>
									<input type="text" value={product_offcer} onChange={(e) => SetProduct_offcer(e.target.value)} placeholder=' Product Offer' className='form-control' required="required" />
								</div>
								<div className="form-group">
									<label> Product Deposit:</label>
									<input type="number" value={product_despoit} onChange={(e) => SetProduct_despoit(e.target.value)} placeholder=' Product Deposit' className='form-control' required="required" />
								</div>
								<div className="form-group">
									<label> Product Valid Offer:</label>
									<input type="text" value={product_valid_offer} onChange={(e) => Setproduct_valid_offer(e.target.value)} placeholder='Product Valid offer' className='form-control' required="required" />
								</div>
								{/* <div className="form-group">
								<label> Product Verified:</label>
								<input type="text" value={product_verified} onChange={(e) => SetProduct_verified(e.target.value)} placeholder=' Product Verified' className='form-control' required="required" />
							</div> */}
								<div className="form-group">
									<label> Product Stock Info:</label>
									<input type="number" value={product_stock_info} onChange={(e) => Setproduct_stock_info(e.target.value)} placeholder=' Product Stock Info' className='form-control' required="required" />
								</div>

								<div className="form-group">
									<label>Product quantity:</label>
									<input type="number" value={product_quantity} onChange={(e) => setProduct_quantity(e.target.value)} placeholder='product quantity' className='form-control' required="required" />
								</div>
								{/* <div className="form-group">
								<label>Product rating:</label>
								<input type="text" value={product_rating} onChange={(e) => SetProduct_rating(e.target.value)} placeholder='Product rating' className='form-control' required="required" />
							</div> */}

								<div className="form-group">
									<label> Product Type:</label>
									<select name="selectList" value={product_rating} className="form-control" onChange={(e) => SetProduct_rating(e.target.value)} placeholder='Contact Name' required="required">

										<option value={1}> 1 </option>
										<option value={1.5}> 1.5 </option>
										<option value={2}> 2 </option>
										<option value={2.5}> 2.5 </option>
										<option value={3}> 3 </option>
										<option value={3.5}> 3.5 </option>
										<option value={4}> 4 </option>
										<option value={4.5}> 4.5 </option>
										<option value={5}> 5 </option>
									</select>

								</div>
								{/* <div className="form-group">
								<label> Product Total review:</label>
								<input type="number" value={product_Total_review} onChange={(e) => SetProduct_Total_review(e.target.value)} placeholder='Product Total review' className='form-control' required="required" />
							</div> */}
								{/* <div className="form-group">
								<label> Product all rating:</label>
								<input type="text" value={product_all_rating} onChange={(e) => SetProduct_all_rating(e.target.value)} placeholder='Product all rating' className='form-control' required="required" />
							</div> */}
								{/* <div className="form-group">
								<label> Product Status:</label>
								<input   type="text" value={product_Status} onChange={(e) => SetProduct_Status(e.target.value)} placeholder='Product Status' className='form-control' required="required" readonly/>
							</div> */}

								<div className="form-group">
									<label> Description:</label>
									<input type="text" value={product_description} onChange={(e) => SetProduct_description(e.target.value)} placeholder='Description' className='form-control' required="required" />
								</div>

								{/* <div className="form-group">
									<label> Cover Image :</label>
									<input type="file" value={product_cover_image} onChange={(e) => SetProduct_cover_image(e.target.value)} placeholder='Product cover image' className='form-control' required="required" />
								</div> */}

								<label htmlFor="file">Upload File:</label>
								<input
									className="form-control-file mb-3"
									type="file" id="file"
                                    name='upload_file'								
									multiple
									onChange={handleFileChange}
								/>

								<div className="form-group">
									<label> Slide Image1:</label>
									<input type="file" value={product_slide_image1} onChange={(e) => SetProduct_slide_image1(e.target.value)} placeholder='product slide image1' className='form-control' required="required" />
								</div>
								<div className="form-group">
									<label> Slide Image2:</label>
									<input type="file" value={product_slide_image2} onChange={(e) => SetProduct_slide_image2(e.target.value)} placeholder='product slide image2' className='form-control' required="required" />
								</div>
								<div className="form-group">
									<label> Slide Image3:</label>
									<input type="file" value={product_slide_image3} onChange={(e) => SetProduct_slide_image3(e.target.value)} placeholder='product slide image3' className='form-control' required="required" />
								</div>
								<div className="form-group">
									<label> Slide Image4:</label>
									<input type="file" value={product_slide_image4} onChange={(e) => SetProduct_slide_image4(e.target.value)} placeholder='product slide image4' className='form-control' required="required" />
								</div>

							</div>
							<div className="box-footer">
								<button className="btn btn-warning" style={{ marginRight: "10px" }}>Reset</button>
								<button type="submit" className="btn  btn-primary" >Add Product</button>
							</div>
							<div >
								{ file.filepreview !==null ?
									<img className="previewing" src={file.filepreview} alt="UploadImage" />
								
								:null
								}
							</div>

						</div>
					</div>
				</div>
			</form>
		</section>

	</>
}
export default AddProduct;




