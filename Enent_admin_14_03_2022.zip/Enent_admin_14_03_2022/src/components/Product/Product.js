import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Spinner from "react-bootstrap/Spinner";
import alertify from 'alertifyjs';
import 'alertifyjs/build/css/alertify.css';

const Product = () => {

  const [product_verified, setProduct_verified] = useState("");
  // const [id, setId] = useState("");

  const options = [
    {
      label: "Approved",
      value: "Approved",

    },
    {
      label: "Declined",
      value: "Declined",

    },
  ]

  const changeStatus = async (e, id) => {
    console.log(e.target.value);
    console.log(id);

    e.preventDefault()

    let item = { 'id': id, "status": e.target.value }

    let result = await fetch("http://34.125.20.72:4260/product_verify_admin", {
      method: 'POST',
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify(item)
    })
    result = await result.json();
    if (result.status == true) {
      alertify.success('Your Status Updated ');
    }



    console.log(result);
    //  window.location.reload();
  }




  // async function statusCheck(e) {

  // 	e.preventDefault()

  //   let item = {status ,id }
  //   let result = await fetch("", {
  // 		method: 'POST',
  // 		headers: {
  // 			"Content-Type": "application/json",
  // 			"Accept": "application/json"
  // 		},
  // 		body: JSON.stringify(item),

  // 	})
  // 	result = await result.json();
  //   console.log("statuscheck",result)
  //   console.log("statuscheckall",item )


  // }


  const [data, setData] = useState([]);
  const getProduct = async () => {
    // const response = await fetch('http://localhost:4260/products');

    // setUsers(await response.json());
    fetch("http://34.125.20.72:4260/products_list_all").then((result) => {
      result.json().then((resp) => {
        setData(resp.data);
        console.log("response data", resp.data);
      });
    });

    $("#lodderGet").css("display", "none");
    //console.log(data);
  };
  useEffect(() => {
    getProduct();
  }, []);
  { console.log("datazds", data) }

  return (
    <>
      <div className="content-header">
        <div className="d-flex align-items-center">
          <div className="mr-auto">
            <div className="d-inline-block align-items-center">
              <nav>
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/">
                      <i className="fa fa-home"></i> Dashboard
                    </Link>
                  </li>
                  <li className="breadcrumb-item">Product </li>
                </ol>
              </nav>
            </div>
          </div>
          <Link to="/AddProduct" className="btn btn-primary">
            {" "}
            <i class="fa fa-plus-circle"></i> Add Product{" "}
          </Link>
        </div>
      </div>
      <section className="content">
        <div className="row">
          <div className="col-12">
            <div className="box">
              <div className="box-header with-border">
                <h4 className="box-title">
                  Product List{" "}
                  <Spinner
                    animation="grow"
                    variant="info"
                    size="2px"
                    style={{ display: "block" }}
                    id="lodderGet"
                  />
                </h4>
                <div className="box-controls pull-right">
                  <div className="lookup lookup-circle lookup-right">
                    <input type="text" name="s" />
                  </div>
                </div>
              </div>
              <div className="box-body no-padding">
                <div className="table-responsive">
                  <table className="table table-hover">
                    <tbody>
                      <tr>
                        <th width="100px">S.NO</th>                      
                        <th width="100px">Product Owner </th>
                        <th width="100px">Product Name </th>
                        <th width="100px">Product QTY</th>
                        <th width="100px">Product Amount</th>

       
            <th width="100px">Status</th>

                        <th width="100px">Actions</th>
                        

                      </tr>


                      {data.map((data, index) => {
                        var selected = (data.Product.product_verified === data.value) ? ' selected' : '';
                        console.log("dataall", data.Product.product_vendor)
                        return (
                          <tr>
                            <td>{index + 1}</td>                        
                            <td>{data.Product.product_vendor ?? "NA"}</td>                            
                            <td>{data.Product.product_name}</td>
                            <td>{data.Product.product_quantity}</td>
                            <td>{data.Product.product_amount}</td>
                            
                            
                      
                  <td><a href="#" class="badge badge-success">Verified</a></td>

                            <td>
                              {console.log("dataproductjdfjk", data.Product)}                              
                              <td><Link to={"/UpdateProduct/" + data.Product.id} className='badge badge-pill badge-warning' ><i class="fa fa-pencil-square-o" aria-hidden="true"></i></Link></td>
                              <td><button className='badge badge-pill badge-danger'><i className='fa fa-trash'></i></button></td>
                            </td>
                          </tr>
                        );
                      })}                
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
export default Product;
