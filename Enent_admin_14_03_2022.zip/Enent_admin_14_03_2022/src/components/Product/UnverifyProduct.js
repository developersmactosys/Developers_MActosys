import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Spinner from "react-bootstrap/Spinner";
import alertify from 'alertifyjs';
import 'alertifyjs/build/css/alertify.css';

const UnverifyProduct = () => {

    const [product_verified, setProduct_verified] = useState("");
    // const [id, setId] = useState("");

    const options = [
        {
            label: "Approved",
            value: "Approved",

        },
        {
            label: "Declined",
            value: "Declined",

        },
    ]



    const changeStatus = async (e, id) => {
        // console.log(e.target.value);
        // console.log(id);

        e.preventDefault()

        let item = { 'id': id, "status": e.target.value }

        let result = await fetch("http://34.125.20.72:4260/product_verify_admin", {
            method: 'POST',
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            body: JSON.stringify(item)
        })
        result = await result.json();
        if (result.status == true) {
            alertify.success('Your Status Updated ');
            setTimeout(function(){ location.reload(); }, 2000);
		
        }



        console.log(result);
        //  window.location.reload();
    }




    // async function statusCheck(e) {

    // 	e.preventDefault()

    //   let item = {status ,id }
    //   let result = await fetch("", {
    // 		method: 'POST',
    // 		headers: {
    // 			"Content-Type": "application/json",
    // 			"Accept": "application/json"
    // 		},
    // 		body: JSON.stringify(item),

    // 	})
    // 	result = await result.json();
    //   console.log("statuscheck",result)
    //   console.log("statuscheckall",item )


    // }


    const [data, setData] = useState([]);
    const getProduct = async () => {
        // const response = await fetch('http://localhost:4260/products');

        // setUsers(await response.json());
        fetch("http://34.125.20.72:4260/unverified_product_list").then((result) => {
            result.json().then((resp) => {
                setData(resp.data);
                console.log("response data", resp.data);
            });
        });

        $("#lodderGet").css("display", "none");
        //console.log(data);
    };
    useEffect(() => {
        getProduct();
    }, []);
    { console.log("datazds", data) }

    return (
        <>
            <div className="content-header">
                <div className="d-flex align-items-center">
                    <div className="mr-auto">
                        <div className="d-inline-block align-items-center">
                            <nav>
                                <ol className="breadcrumb">
                                    <li className="breadcrumb-item">
                                        <Link to="/">
                                            <i className="fa fa-home"></i> Dashboard
                                        </Link>
                                    </li>
                                    <li className="breadcrumb-item">UnverifyProduct </li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    {/* <Link to="/AddProduct" className="btn btn-primary">
            {" "}
            <i class="fa fa-plus-circle"></i> Add Product{" "}
          </Link> */}
                </div>
            </div>
            <section className="content">
                <div className="row">
                    <div className="col-12">
                        <div className="box">
                            <div className="box-header with-border">
                                <h4 className="box-title">
                                    Unverify Product List{" "}
                                    <Spinner
                                        animation="grow"
                                        variant="info"
                                        size="2px"
                                        style={{ display: "block" }}
                                        id="lodderGet"
                                    />
                                </h4>
                                <div className="box-controls pull-right">
                                    <div className="lookup lookup-circle lookup-right">
                                        <input type="text" name="s" />
                                    </div>
                                </div>
                            </div>
                            <div className="box-body no-padding">
                                <div className="table-responsive">
                                    <table className="table table-hover">
                                        <tbody>
                                            <tr>
                                                <th width="100px">S.NO</th>
                                                {/* <th width="100px">Vendor Name</th> */}
                                                <th width="100px">Product Owner </th>
                                                <th width="100px">Product Name </th>
                                                <th width="100px">Product QTY</th>
                                                <th width="100px">Product Amount</th>

                                                {/* <th width="100px">Product category</th> */}
                                                {/* <th width="100px">Select List</th>
						<th width="100px">Product List</th>
						<th width="100px">Product Total Review</th>
						<th width="100px">Product Valid Offer</th>
						<th width="100px">Product All Rating</th> */}
                                                {/* <th width="100px">Product Rating</th>
						<th width="100px">Product Amount</th>
						<th width="100px">Product Deposite</th>
						<th width="100px">Product Description</th>
						<th width="100px">Product Tagline</th>
						<th width="100px">Product Vendor Id</th>
						<th width="100px">Product Verified</th> */}
                                                {/* <th width="100px">Product Vendor</th>
						<th width="100px">Product Cover Image</th>
						<th width="100px">Product Slide Image1</th>
						<th width="100px">Product Slide Image2</th>
						<th width="100px">Product Slide Image3</th>
						<th width="100px">Product Slide Image4</th>
						<th width="100px">Product Stock Info</th> */}
                                                

                                                <th width="100px">UnVerified</th>
                                                <th width="100px">Status</th>
                                                <th width="100px">Actions</th>




                                            </tr>


                                            {data.map((data, index) => {
                                                var selected = (data.Product.product_verified === data.value) ? ' selected' : '';
                                                console.log("dataall", data.Product.product_vendor)
                                                return (
                                                    <tr>
                                                        <td>{index + 1}</td>

                                                        {/* <td>{data.Product.product_vendor}</td>	 */}
                                                        <td>{data.Product.product_vendor ?? "NA"}</td>
                                                        <td>{data.Product.product_vendor}</td>
                                                        <td>{data.Product.product_quantity}</td>
                                                        <td>{data.Product.product_amount}</td>
                                                        {/* <td>{data.Product.product_type}</td> */}
                                                        {/* <td>{data.Product.product_flat_price}</td> */}

                                                        {/* <td>{data.Product.category_id}</td> */}
                                                        {/* <td>{data.Product.selectList}</td>
							<td>{data.Product.productlist}</td>
							<td>{data.Product.product_Total_review}</td>
							<td>{data.Product.product_valid_offer}</td>
							<td>{data.Product.product_all_rating}</td> */}
                                                        {/* <td>{data.Product.product_rating}</td>							
							
							<td>{data.Product.product_deposite}</td>											
							<td>{data.Product.product_description}</td>	
							<td>{data.Product.product_tagline}</td>							
							<td>{data.Product.product_vendor_id}</td>
							<td>{data.Product.product_verified}</td> */}
                                                        {/* <td>{data.Product.product_vendor}</td>						
							<td>{data.Product.product_cover_image}</td>	
							<td>{data.Product.product_slide_image1}</td>
							<td>{data.Product.product_slide_image2}</td>
							<td>{data.Product.product_slide_image3}</td>
							<td>{data.Product.product_slide_image4}</td>
							<td>{data.Product.product_stock_info}</td> */}
                                                       


                                                        <td>

                                                            <select value={data.Product.status} onChange={(e) => changeStatus(e, data.Product.id)}>
                                                                {options.map((option) => {
                                                                    // var selected = (item.tripStatus === option.value) ? ' selected' : '';
                                                                    return <option value={option.value} selected >{option.label}</option>;


                                                                })}
                                                            </select>
                                                        </td>
                                                        <td><a href="#" class="badge badge-danger">UnVerified</a></td>
                                                        <td>
                                                            {console.log("dataproductjdfjk", data.Product)}
                                                            {/* <td><Link to={"/ProductView/"+data.Product.id} className='badge badge-pill badge-warning'><i className='fa fa-eye'></i></Link> </td> */}
                                                            <td><Link to={"/UpdateProduct/" + data.Product.id} className='badge badge-pill badge-warning' ><i class="fa fa-pencil-square-o" aria-hidden="true"></i></Link></td>
                                                            <td><button className='badge badge-pill badge-danger'><i className='fa fa-trash'></i></button></td>
                                                        </td>




                                                        {/* <td>{<select name="selectList"  value={status} onChange={(e) => setStatus(e.target.value)} >
                            <option> Select </option>
                              <option value="Verified" onClick={(e)=> statusCheck(e)} > Approved </option>
                              <option value="Decliend" onClick={(e)=> statusCheck(e)}> Decline </option>
                            </select>}</td> */}



                                                        {/* onClick={()=>deleteUser(data.Category.id)} */}
                                                        {/* <td>
                              <Link
                                to={"/CategoryView/" + data.Category.id}
                                className="badge badge-pill badge-warning"
                              >
                                <i className="fa fa-eye"></i>
                              </Link>
                            </td>
                            <td>
                              <Link
                                to={"/UpdateCategory/" + data.Category.id}
                                className="badge badge-pill badge-warning"
                              >
                                <i
                                  class="fa fa-pencil-square-o"
                                  aria-hidden="true"
                                ></i>
                              </Link>
                            </td> */}
                                                        {/* <td><Link to={"/CategoryView/"+data.Category.id} className='badge badge-pill badge-danger'><i className='fa fa-trash'></i></Link></td> */}
                                                        {/* <td>
                              <button
                                onClick={() => deleteUser(data.Category.id)}
                              >
                                <i className="fa fa-trash"></i>
                              </button>
                            </td>*/}
                                                    </tr>
                                                );
                                            })}

                                            {/* {
							users.map((curElem) =>{
						console.log(curElem);
								return(
									<tr>
										<td>{curElem.id}</td>
										{/* <td>{curElem.name}</td> */}
                                            {/*	<td>
										<ul>
										{curElem.combos.map(combos => (
											<li key={combos.name}>{combos.name}</li>
											))}
											</ul>
										</td>*/}

                                            {/* <td><img src={'https://eventneedz.com'+curElem.image} width={'100px'} alt=''/></td>
									<td>{curElem.description}</td>
									<td>{curElem.lastModifiedDate}</td> */}
                                            {/*<td><Link to={"/UpdateProduct/"+curElem.id} className='badge badge-pill badge-warning' ><i class="fa fa-pencil-square-o" aria-hidden="true"></i></Link></td>
									<td><Link to={"/ProductView/"+curElem.id} className='badge badge-pill badge-warning'><i className='fa fa-eye'></i></Link> <Link to="/" className='badge badge-pill badge-danger'><i className='fa fa-trash'></i></Link></td>
									</tr>*/}
                                            {/*	)*/}

                                            {/*	})
						} */}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
};
export default UnverifyProduct;
