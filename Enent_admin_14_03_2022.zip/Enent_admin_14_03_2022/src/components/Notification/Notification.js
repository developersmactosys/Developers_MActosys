import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

function Notification() {

	const [data, setData] = useState([]);

	const getNotification = () => {
		fetch('http://34.125.20.72:4260/getNotificationAdmin').
			then((result) => {
				result.json().
					then((resp) => {
						setData(resp.data)
						console.log("responsedata", resp.data)
					})
			});

		// $("#lodderGet").css("display", "none");

	}

	useEffect(() => {
		getNotification();
	}, []);

	console.log("datatresponse", data)


	return <>
		<div className="content-header">
			<div className="d-flex align-items-center">
				<div className="mr-auto">
					<div className="d-inline-block align-items-center">
						<nav>
							<ol className="breadcrumb">
								<li className="breadcrumb-item"><Link to="/"><i className="fa fa-home"></i> Dashboard</Link></li>
								<li className="breadcrumb-item"> Notifications </li>
							</ol>
						</nav>
					</div>

				</div>

			</div>
		</div>
		<section className="content">
			<div className="row">
				<div className="col-12">
					<div className="box">
						<div className="box-header with-border">
							<h4 className="box-title">Notifications</h4>
							<div className="box-controls pull-right">
								<div className="lookup lookup-circle lookup-right">
									<input type="text" name="s" />
								</div>
							</div>
						</div>
						<div className="box-body no-padding">


							<div className="table-responsive">
								<table className="table table-hover">
									<tbody><tr>
										<th>S.No</th>
										<th>Message</th>
										<th>Title</th>
										{/* <th>Mobile</th> */}

										<th>Date</th>
									</tr>

										{
											data.map((curElem, ind) => {
												console.log("usersdata", curElem.Notification)

												return (
													<tr>


														<td>{ind + 1}</td>
														<td>{curElem.Notification.message}</td>
														<td>{curElem.Notification.title}</td>
														<td>{curElem.Notification.creationDate}</td>




														{/* <td><Link to="#" className='badge badge-pill badge-warning'>
									 	<i className='fa fa-eye'></i></Link> <Link to="#" className='badge badge-pill badge-danger'>
											<i className='fa fa-trash'></i></Link></td>  */}
													</tr>
												)

											})
										}


									</tbody></table>
							</div>




						</div>
					</div>
				</div>
			</div>
		</section>
	</>
}
export default Notification;