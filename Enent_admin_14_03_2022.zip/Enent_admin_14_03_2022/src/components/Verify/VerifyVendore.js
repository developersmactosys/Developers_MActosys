import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import alertify from 'alertifyjs';
import 'alertifyjs/build/css/alertify.css';

import Spinner from 'react-bootstrap/Spinner'
import { data } from 'jquery';

const verifiedVendore = () => {


	const options = [
		{
			label: "Verified",
			value: "Verified",

		},
		{
			label: "Unverified",
			value: "Unverified",

		},
	]



	const changeStatus = async (e, id) => {	
		e.preventDefault()


		let item = { 'id': id, "status": e.target.value }
		let result = await fetch("http://34.125.20.72:4260/vendor_verify_by_admin", {
			method: 'POST',
			headers: {
				"Content-Type": "application/json",
				"Accept": "application/json"
			},
			body: JSON.stringify(item)
		})
		
		result = await result.json();

		console.log("resul.response", result.status);

		if (result.status == true) {
			alertify.success('Your Status Updated ');				
			// window.location.reload();
			setTimeout(function(){ location.reload(); }, 2000);
		}
		// window.location.reload();



		
		//  window.location.reload();
	}

	const [data, setData] = useState([]);
	const getUsers = () => {
		// fetch('http://192.168.1.22:4260/category_list').
		fetch("http://34.125.20.72:4260/vendor_all_list").
			then((result) => {
				result.json().
					then((resp) => {
						setData(resp.data)
						console.log("", resp.data)
					})
			});

		// $("#lodderGet").css("display", "none");

	}

	useEffect(() => {
		getUsers();
	}, []);

	// function viewOpration(id) {
	// 	alert(id)
	// }
	// function deleteUser(id) {

	// 	fetch(`http://34.125.20.72:4260/category_list/${params.id}`,{
	// 		method:'DELETE'
	// 	}).then((result)=>{
	// 		result.json()
	// 		.then((resp)=>{
	// 			console.warm(resp)
	// 			getUsers()
	// 		})
	// 	})
	// }

	return (
		<>
			<div className="content-header">
				<div className="d-flex align-items-center">
					<div className="mr-auto">
						<div className="d-inline-block align-items-center">
							<nav>
								<ol className="breadcrumb">
									<li className="breadcrumb-item"><Link to="/"><i className="fa fa-home"></i> Dashboard</Link></li>
									<li className="breadcrumb-item">Vendore </li>
								</ol>
							</nav>
						</div>
					</div>
					{/* <Link to="/AddVendor" className='btn btn-primary'> <i class="fa fa-plus-circle"></i> Add Vendore </Link> */}
				</div>
			</div>
			<section className="content">
				<div className="row">
					<div className="col-12">
						<div className="box">
							<div className="box-header with-border">
								<h4 className="box-title">Vendore List  </h4>
								{/* <Spinner animation="grow" variant="info" size="2px" style={{ display: "block" }} id="lodderGet" /> */}
								<div className="box-controls pull-right">
									<div className="lookup lookup-circle lookup-right">
										<input type="text" name="s" />
									</div>
								</div>
							</div>
							<div className="box-body no-padding">
								<div className="table-responsive">
									<table className="table table-hover">
										<tbody><tr>
											<th>S.NO</th>
											<th>Vendor Name</th>
											{/* <th>Description	</th> */}
											<th>Vendore Email</th>
											<th>Vendore Number</th>
											<th>Vendore Business type</th>
											<th>Vendore Address</th>
											<th>Status</th>
											<th>ACTIONS</th>

										</tr>
											{
												data.map((data, index) => {
													console.log("dataasdsad", data)

													return (
														<tr>
															<td>{index + 1}</td>
															<td>{data.Vendor.vendor_name}</td>
															{/* <td>{data.Vendor.vendor_companyName}</td>														 */}
															<td>{data.Vendor.vendor_email}</td>
															<td>{data.Vendor.vendor_mobile}</td>
															<td>{data.Vendor.vendor_businesstype}</td>
															<td>{data.Vendor.vendor_address}</td>


															<td>
																

																<select  value={data.Vendor.status}   onChange={(e) => changeStatus(e, data.Vendor.id)}>
																	{options.map((option) => {
																		// var selected = (item.tripStatus === option.value) ? ' selected' : '';
																		return <option value={option.value} selected >{option.label}</option>;


																	})}
																</select>
															</td>


															<td>
																{/* <td><Link to={"/VendoreView/"+data.category.id} className='badge badge-pill badge-warning' ><i className='fa fa-eye'></i></Link></td>  */}
																<td><Link to={"/UpdateVendore/" + data.Vendor.id} className='badge badge-pill badge-warning' ><i class="fa fa-pencil-square-o" aria-hidden="true"></i></Link></td>
																<td><button className='badge badge-pill badge-danger' ><i className='fa fa-trash'></i></button></td></td>
															{/* onClick={()=>deleteUser(data.category.id)}  */}
														</tr>
													)
												})
											}
										</tbody></table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>

		</>

	)
}
export default verifiedVendore;





