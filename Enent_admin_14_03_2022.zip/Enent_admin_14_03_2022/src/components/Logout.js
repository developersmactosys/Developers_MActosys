
// import React, { Component } from 'react';
// // import { BrowserRouter as Redirect } from 'react-router-dom';

// export default class Logout extends Component {
//     render() 
//     {
//         <div>
//             <h1>you have been log out...</h1>
//             <link to="/">Login</link>
//         </div>
//     }
// }

//  let destoruSession=sessionStorage.removeItem('usrses');
// if(destrouSession=="" || destoruSession=='null')
// {

//     <Redirect to="/" />

// } 
// import * as Cookies from "js-cookie";

// export const sessionStorage = (usrses)=> {
//   Cookies.remove("usrses");
//   Cookies.set("usrses", usrses, { expires: 14 });
// };

// export const sessionStorage= () => {
//   const sessionCookie = Cookies.get("usrses");

//   if (sessionCookie === undefined) {
//     return {};
//   } else {
//     return JSON.parse(sessionCookie);
//   }
// };