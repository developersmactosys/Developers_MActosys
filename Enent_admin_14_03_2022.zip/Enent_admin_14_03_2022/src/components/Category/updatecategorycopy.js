import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
function UpdateCategory(props) {
	const params = useParams();
	const [name, setName] = useState("");
	const [data, setData] = useState([]);
	const [apptype, SetApptype] = useState("");
	const [description, setDescription] = useState("");
	const [image, setImage] = useState("");
	const [id, Setid] = useState("");



	const getCategory = async () => {
		// fetch("http://192.168.1.22:4260/category_by_id/"+ params.id).
		// 	then((result) => {
		// 		result.json().
		// 			then((resp) => {
		// 				setData(resp.data)
		// 				console.log("resp.data", data)
		// 			})
		// 		// setName(data);

		// 		console.log("sasasassasasasasasass",data.name)
		// 		setName(data.name);
		// 		setDescription(data.description)
		// 		setImage(data.image)

		// 		// setData(data)
		// 		// setDescription(result.description)		
		// 		// setImage(result.image)		
		// 		// setData(data);

		// 	});
		let result = await fetch(`http://192.168.1.22:4260/category_by_id/${params.id}`);
		result = await result.json();
		console.log("sasasassasasasasasass",result.data[0].Category.name)
		SetApptype(result.data[0].Category.apptype)
		setName(result.data[0].Category.name);				
		setDescription(result.data[0].Category.description)		
		setImage(result.data[0].Category.image)
		Setid(result.data[0].Category.id)		
		setData(data)
		console.log("hgsfdydf",data)

	}


	useEffect(() => {
		getCategory();
	}, []);

	async function editProduct() {
	
		let result = fetch(`http://192.168.1.22:4260/update_category`, {
			method: 'POST',
			headers: {
				"Content-Type": "application/json",
				"Accept": "application/json"
			},
			
			body: JSON.stringify(resp.data)
			
		})
		// console.log("result", result)
		 console.log("data", data)
	}

	function onchang(event) {
		setData({
			...data,
			[event.target.name]: event.target.value
			

		})

	}

	return <>
		<div className="content-header">
			<div className="d-flex align-items-center">
				<div className="mr-auto">
					<div className="d-inline-block align-items-center">
						<nav>
							<ol className="breadcrumb">
								<li className="breadcrumb-item"><Link to="/"><i className="fa fa-home"></i> Dashboard</Link></li>
								<li className="breadcrumb-item"><Link to="/Category"> Category </Link></li>
								<li className="breadcrumb-item"> Update Category  </li>
							</ol>
						</nav>
					</div>
				</div>

			</div>
		</div>
		<section className="content">
			<div className="row">
				<div className="col-lg-12 col-12">
					<div className="box">


						<div className="box-body">
							<h4 className="mt-0 mb-20">Update Category :</h4>
							<div className="form-group">
								<select name="apptype" value={apptype} className="form-control" onChange={(e) => { onchang(e); SetApptype(e.target.value) }} placeholder='Contact Name' className='form-control' required="required">
									<option> Add Type </option>
									<option value="RENT"> Rent </option>
									<option value="SELL"> Sell </option>
								</select>
							</div>
							<div className="form-group">
								<label> Name:</label>
								<input type="text" name='name' value={name} className='form-control' placeholder='Name' onChange={(e) => { onchang(e); setName(e.target.value) }} />
							</div>
							<div className="form-group">
								<label> id:</label>
								<input type="hidden" name='id' value={id} className='form-control' placeholder='Name' onChange={(e) => { onchang(e); Setid(e.target.value) }} />
							</div>
							<div className="form-group">
								<label> description:</label>
								<input type="text" name='description' value={description} onChange={(e) => { onchang(e); setDescription(e.target.value) }} placeholder='Description' className='form-control' />
							</div>
							<div className="form-group">
								<label> image:</label>
								<input type="text" name='image' value={image} onChange={(e) => { onchang(e); setImage(e.target.value) }} placeholder='image' className='form-control' />
							</div>

						</div>
						<div className="box-footer">
							{/* <button className="btn  btn-primary" onClick={() => editProduct(data.id)}>Update Category</button> */}
							<button className="btn  btn-primary" onClick={() => editProduct()}>Update Category</button>
						</div>


					</div>
				</div>
			</div>
		</section>

	</>
}
export default UpdateCategory;