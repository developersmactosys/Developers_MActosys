
export const CatApi= [
    {
        id:1,
        Name : 'Category 1',
        Photo : 'https://eduadmin-template.multipurposethemes.com/bs4/images/gallery/full/10.jpg',
        TotalProduct : '100',
        Status : 'active'
    },
    {
        id:2,
        Name : 'Category 2',
        Photo : 'https://eduadmin-template.multipurposethemes.com/bs4/images/gallery/full/10.jpg',
        TotalProduct : '500',
        Status : 'Pending'
    },
    {
        id:3,
        Name : 'Category 3',
        Photo : 'https://eduadmin-template.multipurposethemes.com/bs4/images/gallery/full/10.jpg',
        TotalProduct : '1020',
        Status : 'active'
    },
    
    ]