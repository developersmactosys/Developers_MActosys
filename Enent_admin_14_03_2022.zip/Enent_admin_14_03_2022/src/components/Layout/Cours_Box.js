import React from 'react';
import {Link } from "react-router-dom";

const CoursBox = ({courseTitle,courseLink,courseImg})=>{
    return(
        <>
            <div className="box">
                <div className="fx-card-item">
                    <div className="fx-card-avatar fx-overlay-1"> <img src={courseImg} alt="user" className="bbrr-0 bblr-0" />
                        <div className="fx-overlay">
                            <ul className="fx-info">
                                <li>
                                    <Link to={courseLink} className="btn btn-danger no-border">View more</Link>
                                   </li>
                            </ul>
                        </div>
                    </div>
                    <div className="fx-card-content">
                        <h4 className="box-title mb-0">{courseTitle}</h4>
                    </div>
                </div>
            </div>
        </>
    )
    

}
export default CoursBox;