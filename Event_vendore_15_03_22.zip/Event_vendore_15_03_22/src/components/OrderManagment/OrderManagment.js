import React, { useState, useEffect } from "react";
import { Link, useParams } from 'react-router-dom';
// import Spinner from "react-bootstrap/Spinner";
import alertify from 'alertifyjs';
import 'alertifyjs/build/css/alertify.css';

const Product = () => {

  const [product_verified, setProduct_verified] = useState("");
  // const [id, setId] = useState("");

  const options = [
    {
      label: "Approved",
      value: "Approved",

    },

    {
      label: "Reject",
      value: "Reject",

    },
    {
      label: "Deliver",
      value: "Deliver",

    },
    {
      label: "Pending",
      value: "Pending",

    },
  ]

  const changeStatus = async (e, id) => {
    // console.log(e.target.value);
    // console.log(id);

    e.preventDefault()

    let item = { 'id': id, "order_status": e.target.value, "vendor_id": vin_id }

    console.log("itemcheck", item)

    let result = await fetch("http://34.125.20.72:4260/order_status_change", {
      method: 'POST',
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify(item)
    })
  
    result = await result.json();


    console.log("responsecheck", result)


    if (result.success == true) {
      alertify.success('Your Status Updated ');
      setTimeout(function () { location.reload(); }, 2000);

    }



    console.log(result);
    //  window.location.reload();
  }

  const params = useParams();
  const alldataset = JSON.parse(sessionStorage.getItem('vendore-info'));


  var product_vendor = alldataset.result[0].Vendor.vendor_name;

  var vin_id = alldataset.result[0].Vendor.id;

  const [data, setData] = useState([]);
  const getBooking = () => {
    // fetch('http://192.168.1.22:4260/category_list').
    fetch(`http://34.125.20.72:4260/vendor_booking_list/${vin_id}`).
      then((result) => {
        result.json().
          then((resp) => {
            setData(resp.data)
            console.log("datata", resp.data)
          })
      });

    console.log("responseall data", data)

    // $("#lodderGet").css("display", "none");

  }
  useEffect(() => {
    getBooking();
  }, []);
  { console.log("amngmentdata", data) }
  if(data){
  return (
    <>
      <div className="content-header">
        <div className="d-flex align-items-center">
          <div className="mr-auto">
            <div className="d-inline-block align-items-center">
              <nav>
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/">
                      <i className="fa fa-home"></i> Dashboard
                    </Link>
                  </li>
                  <li className="breadcrumb-item">Order Managment </li>
                </ol>
              </nav>
            </div>
          </div>

        </div>
      </div>
      <section className="content">
        <div className="row">
          <div className="col-12">
            <div className="box">
              <div className="box-header with-border">
                <h4 className="box-title">
                  Order Managment{" "}
                  {/* <Spinner
                                        animation="grow"
                                        variant="info"
                                        size="2px"
                                        style={{ display: "block" }}
                                        id="lodderGet"
                                    /> */}
                </h4>
                <div className="box-controls pull-right">
                  <div className="lookup lookup-circle lookup-right">
                    <input type="text" name="s" />
                  </div>
                </div>
              </div>
              <div className="box-body no-padding">
                <div className="table-responsive">
                  <table className="table table-hover">
                    <tbody>
                      <tr>
                        <th width="30px">S.NO</th>
                        <th width="100px">Booking Id </th>
                        <th width="100px">Product Name</th>
                        <th width="100px">Quantity</th>
                        <th width="100px">Total Amount</th>
                        <th width="100px">Date</th>
                        <th width="100px">Status</th>
                      </tr>


                      {data.map((data, index) => {

                        console.log("datamangment", data.Booking)
                        var status_booking = '';
                        var class_tag = '';
                        if (data.Booking.order_status == 'NEW') {
                          status_booking = 'Pending';
                          var class_tag = 'badge badge-pill badge-warning';

                        } else if (data.Booking.order_status == 'Delivered') {
                          status_booking = 'Delivered';
                          var class_tag = 'badge badge-pill badge-success';
                        }
                        else if (data.Booking.order_status == 'rejected') {
                          status_booking = 'Rejected';
                          var class_tag = 'badge badge-pill badge-danger';
                        }

                        console.log("dataalllisting", data)
                        return (
                          <tr>
                            <td>{index + 1}</td>
                            <td>{data.Booking.order_no ?? "NA"}</td>
                            <td>{data.Booking.product_nam ?? "NA"}</td>
                            <td>{data.Booking.quantity ?? "NA"}</td>
                            <td>{data.Booking.total_amount ?? "NA"}</td>
                            {/* <td class={class_tag}>{status_booking}</td> */}
                            <td>{data.Booking.creationDate ?? "NA"}</td>
                            <td>
                              <select className="form-control" value={data.Booking.order_status} onChange={(e) => changeStatus(e, data.Booking.id)}>
                                {options.map((option) => {
                                  // var selected = (item.tripStatus === option.value) ? ' selected' : '';
                                  return <option value={option.value} selected >{option.label}</option>;
                                })}
                              </select>
                            </td>                      





                          </tr>
                        );
                      })}


                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );

  
}else
{
  return (
 <>
  <div className="content-header">
    <div className="d-flex align-items-center">
      <div className="mr-auto">
        <div className="d-inline-block align-items-center">
          <nav>
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link to="/">
                  <i className="fa fa-home"></i> Dashboard
                </Link>
              </li>
              <li className="breadcrumb-item">Order Mangment </li>
            </ol>
          </nav>
        </div>
      </div>

    </div>
  </div>
  {/* style={{color: "red"}} */}
  <h3 style={{textAlign: "center",color: "red",margin:"20%" }}>No Data Found</h3>
  </>
  
  )
}
};
export default Product;
