import React, { useState, useEffect } from "react";
import { Link,useParams } from "react-router-dom";
import Spinner from "react-bootstrap/Spinner";




import BoxHeader from '../Layout/Box_Header';
import CourseClass from '../Layout/Course_Class';
import CoursBox from '../Layout/Cours_Box';
import icon1 from '../../images/front-end-img/courses/cor-logo-6.png';
import icon2 from '../../images/front-end-img/courses/cor-logo-3.png';
import icon3 from '../../images/front-end-img/courses/cor-logo-4.png';
import icon4 from '../../images/front-end-img/courses/cor-logo-5.png';
import icon5 from '../../images/front-end-img/courses/1.png';
import icon6 from '../../images/front-end-img/courses/2.png';
import icon7 from '../../images/front-end-img/courses/3.png';
import icon8 from '../../images/front-end-img/courses/4.png';
import { useRowSelect } from "react-table";
 
function Home (){




  const [user, setUser] = useState('')
  const [data, setData] = useState([])


	
  const alldataset = JSON.parse(sessionStorage.getItem('vendore-info'));
  var product_vendor =alldataset.result[0].Vendor.vendor_name;  
  var vin_id =alldataset.result[0].Vendor.id;




  // const [category, setCategory] = useState([]);
 
  // const getcategory = () => {


	
	// 	fetch('http://34.125.20.72:4260/category_list').
	// 		then((result) => {
	// 			result.json().
	// 				then((resp) => {
	// 					setCategory(resp.data)
	// 					console.log("", resp.data)
	// 					// console.log("Allldaat", dataVendore.result[0].Vendor.id)
	// 				})
	// 		});


	// }












  const fetchData = () => {

    fetch(`http://34.125.20.72:4260/getDashboard`)

      .then(response => {

        return response.json()

      })

      .then(data => {

        setUser(data)
       

      })

  }

  const getCategory = () => {

    fetch(`http://34.125.20.72:4260/categoryDashboard`)

      .then(response => {
        return response.json()
      })
      .then(dataAll => {
        setData(dataAll.data)
      
      })

  }
  


  // console.log("daataall124154",data.length);







  useEffect(() => {

    fetchData()
    getCategory()
    // getcategory();

  }, [])

  console.log("data.name",user );
  // console.log("categorydata ",data.category.name);


     return <>
      <section className="content">
     
   <div class="row">


     
    
     <div className="col-md-3"><CourseClass  CclassTitle='Total Products' CclassLink={user.product_total} CclassImg={icon4}/></div>
     <div className="col-md-3"><CourseClass  CclassTitle='Total Customer' CclassLink={user.count_users} CclassImg={icon1}/></div>
     <div className="col-md-3"><CourseClass  CclassTitle='Total Orders Executed' CclassLink={user.booking_total} CclassImg={icon3}/></div>
     <div className="col-md-3"><CourseClass  CclassTitle='Orders In Process' CclassLink={user.booking_total_inprogresss} CclassImg={icon2}/></div>
 </div>
 <div className="row fx-element-overlay"> 
    <div className="col-lg-6 col-12">
      <div className="box ">
      <div className="box-header">
							<h4 className="box-title">Popular Category</h4>
							{/* <h5 className='pull-right'>Total Category :{user.pr </h5> */}
						</div>
            <div className='box-body'><div className="row">
            {data && data.map((data, index) => {

              console.log("123456",data.category.image)
												return (
<>

           
                            {/* <div className="col-lg-6 col-md-6 col-12"><CoursBox  courseTitle={data} courseLink={data} courseImg={icon5}/></div>*/}
                            <div className="col-lg-6 col-md-6 col-12"><CoursBox  courseTitle={data.category.name} courseLink='#Anchor' courseImg={data.category.image}/></div>
                            {/* <div className="col-lg-6 col-md-6 col-12"><CoursBox  courseTitle='Birthday' courseLink='#Birthday' courseImg={icon7}/></div>
                            <div className="col-lg-6 col-md-6 col-12"><CoursBox  courseTitle='Caterer' courseLink='#Caterer' courseImg={icon8}/></div>  */}
                        
                 
                          </>
												)
											})} </div> </div>
             
        <div className='box-body'>
          <div className="row"> 
            {/* <div className="col-lg-6 col-md-6 col-12"><CoursBox  courseTitle="" courseLink={data.length} courseImg={icon5}/></div>
            <div className="col-lg-6 col-md-6 col-12"><CoursBox  courseTitle='Anchor' courseLink='#Anchor' courseImg={icon6}/></div>
            <div className="col-lg-6 col-md-6 col-12"><CoursBox  courseTitle='Birthday' courseLink='#Birthday' courseImg={icon7}/></div>
            <div className="col-lg-6 col-md-6 col-12"><CoursBox  courseTitle='Caterer' courseLink='#Caterer' courseImg={icon8}/></div> */}
          </div>
        </div>
      </div>
    </div>
    <div className="col-lg-6 col-12">
      <div className="box ">
        <BoxHeader  boxTitle='Analytics'  />
          <div className='box-body'>
          <div id="charts_widget_1_chart"></div>
          </div>
        </div>
    </div>
</div>
  </section>
</>
}
 
export default Home;