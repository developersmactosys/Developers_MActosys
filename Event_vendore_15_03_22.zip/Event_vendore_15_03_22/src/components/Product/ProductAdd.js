
import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom';
import alertify from 'alertifyjs';
import 'alertifyjs/build/css/alertify.css';
import AddCategory from '../Category/AddCategory';
import { Alert } from 'bootstrap';
const axios = require('axios');


// const alldataset = JSON.parse(sessionStorage.getItem('vendore-info'));
// console.log("dataid", alldataset.result[0].Vendor.id)
// // console.log("resultfgffd",data.result[0].Vendor.vendor_name)
// var Vendore_id='';
// if(alldataset !=null){
//   var Vendore_id=alldataset.result[0].Vendor.id
// }




function AddProduct() {

	//########################################### sinle images add ########################################################################


		// const [userInfo, setUserInfo] = useState({
		// 		files: [],
		// 		filepreview: null
		// 	});

		// const handleFileChange = (event) => {
		// 		setUserInfo({
		// 			...userInfo,
		// 			files: event.target.files[0],
		// 			filepreview: URL.revokeObjectURL(event.target.files[0]),
		
		
		// 		})
		// 	}

	// 			const submit = async () => {
	// 	const formData = new FormData();
	// 	formData.append('file', userInfo.files );

	// 	axios.post("http://34.125.20.72:4260/movetoupload", formData, {
	// 		//headers: { "Content-Type": "multipart/form-data" }
	// 	})
	// 		.then(res => {
	// 			console.log(res)
	// 		})

	// }

//########################################### single images closed ########################################################################



	// const [vendore_id, setVendore_Id] = useState({
	// 	"vendore_Id":  dataVendore.result[0].Vendor.id
	// });
	// console.log("vendore_Id",vendore_Id)


	// const [selectedImages, setSelectedImages] = useState([]);
	const [product_amount, SetProduct_amount] = useState("");
	const [product_tagline, SetProduct_tagline] = useState("");
	const [product_slide_image1, SetProduct_slide_image1] = useState("");
	const [product_slide_image2, SetProduct_slide_image2] = useState("");
	const [product_slide_image3, SetProduct_slide_image3] = useState("");
	const [product_slide_image4, SetProduct_slide_image4] = useState("");
	const [selectList, SetSelectList] = useState("");
	console.log("selectList",selectList);
	if(selectList =='RENT')
{
	$("#ProductDeposit").show()

}
else if(selectList=='SELL')
{
	$("#ProductDeposit").hide()
}
	// const [product_vendor, setProduct_vendor] = useState("");
	const [ProductType, setProductType] = useState("");

	const [product_flat_price, SetProduct_flat_price] = useState("");
	const [product_offcer, SetProduct_offcer] = useState("");
	const [product_despoit, SetProduct_despoit] = useState("");
	const [product_valid_offer, Setproduct_valid_offer] = useState("");
	const [product_stock_info, Setproduct_stock_info] = useState("");
	const [product_rating, SetProduct_rating] = useState("");
	const [product_cover_image, SetProduct_cover_image] = useState("");

	const [product_name, SetProduct_name] = useState("");
	const [category_id, setCategoryss_id] = useState("");
	//console.log("category_id",category_id)
	const [product_quantity, setProduct_quantity] = useState("");
	const [product_description, SetProduct_description] = useState("");

	const [category, setCategory] = useState([]);

	useEffect(() => {
		getcategory();
	}, []);
  

	const getcategory = () => {


		// fetch('http://192.168.1.22:4260/category_list').
		fetch('http://34.125.20.72:4260/category_list').
			then((result) => {
				result.json().
					then((resp) => {
						setCategory(resp.data)
						// console.log("", resp.data)
						// console.log("Allldaat", dataVendore.result[0].Vendor.id)
					})
			});


	}

//########################################### multi images add ########################################################################

// const  imageHandleChange = (e) =>{
// 	if(e.target.files){
// 		const fileArray = Array.from(e.target.files).map((file)=>URL.createObjectURL(file))
// 		console.log(fileArray)

// 		setSelectedImages((prevImages)=>prevImages.concat(fileArray))
// 		Array.from(e.target.files).map(
// 			(file)=URL.revokeObjectURL(file)
// 		)
// 	}

// }

// const  imageHandleChange = (e) =>{
// 	if(e.target.files){
// 		const fileArray = Array.from(e.target.files).map((file)=>URL.createObjectURL(file))
// 		console.log(fileArray)

// 		setSelectedImages((prevImages)=>prevImages.concat(fileArray))
// 		Array.from(e.target.files).map(
// 			(file)=URL.revokeObjectURL(file)
// 		)
// 	}

// }

// const renderPhoto = (source)=>{
// 	return source.map((photo)=>{
// 		return <img width={50} src={photo} key={photo} />
// 	})
// }




//########################################### multi images closed ########################################################################


/*    SetSelectList = (e) =>{


if(SetSelectList(e.target.value =='RENT'))
{
	$("#ProductDeposit").show()

}
else if(SetSelectList(e.target.value=='SELL'))
{
	$("#ProductDeposit").hide()
}




 } */













	async function addinfo(e) {

		e.preventDefault()	
		
		const alldataset = JSON.parse(sessionStorage.getItem('vendore-info'));	
		// var Vendore_id = dataVendore.result[0].Vendor.id
		var product_vendor =alldataset.result[0].Vendor.vendor_name;		
			var product_vendor_id =alldataset.result[0].Vendor.id;





		let item = {product_vendor,product_vendor_id,  category_id, product_slide_image1, product_slide_image2, product_slide_image3, product_slide_image4, selectList, product_cover_image, product_offcer, product_rating, product_stock_info, product_valid_offer, product_despoit, product_flat_price, ProductType, product_name, product_quantity, product_description, product_tagline, product_amount }


		
			let result = await fetch("http://34.125.20.72:4260/add_product_admin", {
			method: 'POST',
			headers: {
				"Content-Type": "application/json",
				"Accept": "application/json"
			},
			body: JSON.stringify(item)
		})
		result = await result.json();


		if (result.id) {
			alertify.success('Your Product Successfull Added Please wait for verification ');
		}			 	
		
		
		SetProduct_amount("");
		SetProduct_tagline("");
		SetProduct_name("");	
		setProductType("");
		SetProduct_flat_price("");
		SetProduct_offcer("");
		SetProduct_despoit("");
		Setproduct_stock_info("");
		SetProduct_rating("");
		SetProduct_cover_image("");
		SetProduct_slide_image1("");
		SetProduct_slide_image2("");
		SetProduct_slide_image3("");
		SetProduct_slide_image4("");
		setCategoryss_id("")
		SetProduct_name("")
		Setproduct_valid_offer("")
		setProduct_quantity("");
		SetProduct_description("");
		// SetSelectList("");
	}

	


	return <>
		<div className="content-header">
			<div className="d-flex align-items-center">
				<div className="mr-auto">
					<div className="d-inline-block align-items-center">
						<nav>
							<ol className="breadcrumb">
								<li className="breadcrumb-item"><Link to="/"><i className="fa fa-home"></i> Dashboard</Link></li>
								<li className="breadcrumb-item"><Link to="/product"> Product </Link></li>
								<li className="breadcrumb-item">Add Product</li>
							</ol>
						</nav>
					</div>
				</div>

			</div>
		</div>
		<section className="content">
		{/* & submit(e) */}
			<form onSubmit={(e) => addinfo(e)  } enctype="multipart/form-data">
				<div className="row">
					<div className="col-lg-12 col-12">
						<div className="box">
							<div className="box-body">
								<h4 className="mt-0 mb-20">Add Product :</h4>
								{/* <div className="form-group" enctype="multipart/form-data">
									<label>Name: </label>	

									<input type="text" value={product_vendor} onChange={(e) => setProduct_vendor(e.target.value)} placeholder=' Product Name' className='form-control' required="required" />
								</div> */}

								<div className="form-group">
								{/* <label> category id: </label>
								<input type="text" value={selectList} onChange={(e) => SetSelectList(e.target.value)} placeholder=' Product Name' className='form-control' required="required" /> */}
									{/* <div className="form-group">
										<label> App Type: </label>
										<select  value={selectList}  className="form-control" onChange={ValueChanged} placeholder='App Type' required="required">
										<option > Select </option>
											<option value="SELL"> Sell </option>
											<option value="RENT"> rent </option>

										</select>
									</div> */}

									<div className="form-group">
										<label> App Type: </label>
										<select  value={selectList} className="form-control" onChange={(e) => SetSelectList(e.target.value)} placeholder='App Type' required="required">
										<option > Select AppType </option>
											<option value="SELL"> Sell </option>
											<option value="RENT"> rent </option>

										</select>
									</div>





									<div className="form-group">
										<label> category: </label>
										<select  value={category_id} className="form-control" onChange={(e) => setCategoryss_id(e.target.value)} placeholder='Category' required >

											{category && category.map((data, index) => {
												return (

													<option value={data.category.id} >{data.category.name} </option>
												)
											})}

										</select>
									</div>

								</div>		
								{/* <div className="form-group">
									
									<input type="hidden" value={vendore_id} onChange={(e) => setVendore_Id(e.target.value)} placeholder=' vendore Name' className='form-control'  />
								</div>					 */}
								<div className="form-group">
									<label> Product Name:</label>
									<input type="text" value={product_name} onChange={(e) => SetProduct_name(e.target.value)} placeholder=' Product Name' className='form-control' required="required" />
								</div>
								<div className="form-group">
								{/* <label> Product data:</label>
									<input type="text" value={ProductType} onChange={(e) => setProductType(e.target.value)} placeholder=' Product Name' className='form-control' required="required" /> */}
									<label> Product Type:</label>
									<select  value={ProductType} className="form-control" onChange={(e) => setProductType(e.target.value)} placeholder='Product type'>
									<option > Select </option>
										<option value="FEATURE"> Feature </option>
										<option value="RECOMMENDED"> Recommended </option>
									</select>

								</div>
								<div className="form-group">
									<label> Product Tagline:</label>
									<input type="text" value={product_tagline} onChange={(e) => SetProduct_tagline(e.target.value)} placeholder=' Product Tagline' className='form-control' required="required" />
								</div>
								<div className="form-group">
									<label> Product Flat Price: </label>
									<input type="number" name="quantity" value={product_flat_price} onChange={(e) => SetProduct_flat_price(e.target.value)} placeholder=' ProductFlate Price' className='form-control' required="required" />
								</div>
								<div className="form-group">
									<label> Product Amount: </label>
									<input type="number" name="quantity" value={product_amount} onChange={(e) => SetProduct_amount(e.target.value)} placeholder=' Product Flate Price' className='form-control' required="required" />
								</div>
								<div className="form-group">
									<label> Product Offer:</label>
									<input type="text" value={product_offcer} onChange={(e) => SetProduct_offcer(e.target.value)} placeholder=' Product Offer' className='form-control' required="required" />
								</div>
								<div className="form-group" id= 'ProductDeposit' >
									<label> Product Deposit:</label>
									<input type="number" value={product_despoit} onChange={(e) => SetProduct_despoit(e.target.value)} placeholder=' Product Deposit' className='form-control'  />
								</div>
								<div className="form-group">
									<label> Product Valid Offer:</label>
									<input type="text" value={product_valid_offer} onChange={(e) => Setproduct_valid_offer(e.target.value)} placeholder='Product Valid offer' className='form-control' required="required" />
								</div>
								{/* <div className="form-group">
								<label> Product Verified:</label>
								<input type="text" value={product_verified} onChange={(e) => SetProduct_verified(e.target.value)} placeholder=' Product Verified' className='form-control' required="required" />
							</div> */}
								<div className="form-group">
									<label> Product Stock Info:</label>
									<input type="number" value={product_stock_info} onChange={(e) => Setproduct_stock_info(e.target.value)} placeholder=' Product Stock Info' className='form-control' required="required" />
								</div>

								<div className="form-group">
									<label>Product quantity:</label>
									<input type="number" value={product_quantity} onChange={(e) => setProduct_quantity(e.target.value)} placeholder='product quantity' className='form-control' required="required" />
								</div>
								{/* <div className="form-group">
								<label>Product rating:</label>
								<input type="text" value={product_rating} onChange={(e) => SetProduct_rating(e.target.value)} placeholder='Product rating' className='form-control' required="required" />
							</div> */}

								<div className="form-group">
									<label> Product Rating:</label>
									<select  value={product_rating} className="form-control" onChange={(e) => SetProduct_rating(e.target.value)} placeholder='Contact Name' required="required">
										<option value="1"> 1 </option>
										<option value={1.5}> 1.5 </option>
										<option value={2}> 2 </option>
										<option value={2.5}> 2.5 </option>
										<option value={3}> 3 </option>
										<option value={3.5}> 3.5 </option>
										<option value={4}> 4 </option>
										<option value={4.5}> 4.5 </option>
										<option value={5}> 5 </option>
									</select>

								</div>
								{/* <div className="form-group">
								<label> Product Total review:</label>
								<input type="number" value={product_Total_review} onChange={(e) => SetProduct_Total_review(e.target.value)} placeholder='Product Total review' className='form-control' required="required" />
							</div> */}
								{/* <div className="form-group">
								<label> Product all rating:</label>
								<input type="text" value={product_all_rating} onChange={(e) => SetProduct_all_rating(e.target.value)} placeholder='Product all rating' className='form-control' required="required" />
							</div> */}
								{/* <div className="form-group">
								<label> Product Status:</label>
								<input   type="text" value={product_Status} onChange={(e) => SetProduct_Status(e.target.value)} placeholder='Product Status' className='form-control' required="required" readonly/>
							</div> */}

								<div className="form-group">
									<label> Description:</label>
									<input type="text" value={product_description} onChange={(e) => SetProduct_description(e.target.value)} placeholder='Description' className='form-control' required="required" />
								</div>

								<div className="form-group">
									<label> Cover Image :</label>
									<input type="file" value={product_cover_image} onChange={(e) => SetProduct_cover_image(e.target.value)} placeholder='Product cover image' className='form-control' required="required" />
								</div>

                                {/* <div className="form-group">
								<label htmlFor="file">Upload File:</label>								
                                <input type="file"  className='form-control' multiple  name='file' onChange={handleFileChange} />
								</div> */}
								
								 {/* <div className="form-group">
									<label> Multi Images</label>
									<input type="file" id='file'   onChange={imageHandleChange} multiple />
									<div className='label-holder' >
										<label htmlFor='file' className='label'>
											<i className='material-icons'>Add_Image</i>
										</label>
									</div>
									<div width="100" className='result'>
										{renderPhoto(selectedImages)}
										
									</div>
								</div> */}
								



								<div className="form-group">
									<label> Slide Image1:</label>
									<input type="file" value={product_slide_image1} onChange={(e) => SetProduct_slide_image1(e.target.value)} placeholder='product slide image1' className='form-control' required="required" />
								</div>
								<div className="form-group">
									<label> Slide Image2:</label>
									<input type="file" value={product_slide_image2} onChange={(e) => SetProduct_slide_image2(e.target.value)} placeholder='product slide image2' className='form-control' required="required" />
								</div>
								<div className="form-group">
									<label> Slide Image3:</label>
									<input type="file" value={product_slide_image3} onChange={(e) => SetProduct_slide_image3(e.target.value)} placeholder='product slide image3' className='form-control' required="required" />
								</div>
								<div className="form-group">
									<label> Slide Image4:</label>
									<input type="file" value={product_slide_image4} onChange={(e) => SetProduct_slide_image4(e.target.value)} placeholder='product slide image4' className='form-control' required="required" />
								</div>

							</div>
							<div className="box-footer">
								<button className="btn btn-warning" style={{ marginRight: "10px" }}>Reset</button>
								<button type="submit" className="btn  btn-primary" >Add Product</button>
							</div>
						

						</div>
					</div>
				</div>
			</form>
		</section>

	</>
}
export default AddProduct;
















// ####################################################################################Etra old work ######################################################################




// import React, { useState, useEffect } from 'react'

// const axios = require('axios');




// function AddProduct() {

// 	const [userInfo, setUserInfo] = useState({
// 		file: [],
// 		filepreview: null
// 	});

// 	const handleFileChange = (event) => {
// 		setUserInfo({
// 			...userInfo,
// 			file: event.target.files[0],
// 			filepreview: URL.revokeObjectURL(event.target.files[0]),


// 		})
// 	}

// 	const submit = async () => {
// 		const formData = new FormData();
// 		formData.append('file', userInfo.file);

// 		axios.post("http://34.125.20.72:4260/movetoupload", formData, {
// 			headers: { "Content-Type": "multipart/form-data" }
// 		})
// 			.then(res => {
// 				console.log(res)
// 			})

// 	}







// 	return <>

// 		<section className="content">
			
		
// 				<div>
// 					<input type="file" className='form-control' name='upload_file' onChange={handleFileChange} />
// 					</div>
// 					<div>
// 						<button type='submit' className='btn btn-dark' onClick={()=>submit()}
// 						></button>
// 					</div>
		
			
// 		</section>

// 	</>
// }
// export default AddProduct;









// import React, { useState, useEffect } from 'react'
// import { Link } from 'react-router-dom';
// import alertify from 'alertifyjs';
// import 'alertifyjs/build/css/alertify.css';

// import { Alert } from 'bootstrap';
// const axios = require('axios');




// function AddProduct() {


// 	// const [userInfo, setUserInfo] = useState({
// 	// 			file: [],
// 	// 			filepreview: null
// 	// 		});


// 	const [product_amount, SetProduct_amount] = useState("");
// 	const [product_tagline, SetProduct_tagline] = useState("");
// 	const [product_slide_image1, SetProduct_slide_image1] = useState("");
// 	const [product_slide_image2, SetProduct_slide_image2] = useState("");
// 	const [product_slide_image3, SetProduct_slide_image3] = useState("");
// 	const [product_slide_image4, SetProduct_slide_image4] = useState("");
// 	const [selectList, SetSelectList] = useState("");
// 	const [product_vendor, setProduct_vendor] = useState("");
// 	const [ProductType, SetProductType] = useState("");
// 	const [product_flat_price, SetProduct_flat_price] = useState("");
// 	const [product_offcer, SetProduct_offcer] = useState("");
// 	const [product_despoit, SetProduct_despoit] = useState("");
// 	const [product_valid_offer, Setproduct_valid_offer] = useState("");
// 	const [product_stock_info, Setproduct_stock_info] = useState("");
// 	const [product_rating, SetProduct_rating] = useState("");
// 	const [product_cover_image, SetProduct_cover_image] = useState("");

// 	const [product_name, SetProduct_name] = useState("");
	
// 	const [product_quantity, setProduct_quantity] = useState("");
// 	const [product_description, SetProduct_description] = useState("");





// 	// const submit = async () => {
// 	// 	const formData = new FormData();
// 	// 	formData.append('file', userInfo.file);

// 	// 	axios.post("http://34.125.20.72:4260/movetoupload", formData, {
// 	// 		headers: { "Content-Type": "multipart/form-data" }
// 	// 	})
// 	// 		.then(res => {
// 	// 			console.log(res)
// 	// 		})

// 	// }


// 	// const handleFileChange = (event) => {
// 	// 			setUserInfo({
// 	// 				...userInfo,
// 	// 				file: event.target.files[0],
// 	// 				filepreview: URL.revokeObjectURL(event.target.files[0]),
		
		
// 	// 			})
// 	// 		}

	



// 	async function addinfo(e) {

// 		e.preventDefault()

// 		let item = { product_vendor, product_slide_image1, product_slide_image2, product_slide_image3, product_slide_image4, selectList, product_cover_image, product_offcer, product_rating, product_stock_info, product_valid_offer, product_despoit, product_flat_price, ProductType, product_name, product_quantity, product_description, product_tagline, product_amount }


// 		// let result = await fetch("", {
// 		// let result = await fetch("http://34.125.20.72:4260/movetoupload", {
// 			let result = await fetch("http://34.125.20.72:4260/add_product_admin", {
// 			method: 'POST',
// 			headers: {
// 				"Content-Type": "application/json",
// 				"Accept": "application/json"
// 			},
// 			body: JSON.stringify(item)
// 		})
// 		result = await result.json();


// 		if (result.id) {
// 			alertify.success('Your Product Successfull Added Please wait for verification ');
// 		}
	

			 	

// 		SetProduct_amount("");
// 		SetProduct_tagline("");
// 		SetProduct_name("");
// 		setProduct_vendor("");
// 		SetProductType("");
// 		SetProduct_flat_price("");
// 		SetProduct_offcer("");
// 		SetProduct_despoit("");
// 		Setproduct_stock_info("");
// 		SetProduct_rating("");
// 		SetProduct_cover_image("");
// 		SetProduct_slide_image1("");
// 		SetProduct_slide_image2("");
// 		SetProduct_slide_image3("");
// 		SetProduct_slide_image4("");
	
// 		SetProduct_name("")
// 		Setproduct_valid_offer("")
// 		setProduct_quantity("");
// 		SetProduct_description("");
// 		SetSelectList("");
// 	}

	


// 	return <>
// 		<div className="content-header">
// 			<div className="d-flex align-items-center">
// 				<div className="mr-auto">
// 					<div className="d-inline-block align-items-center">
// 						<nav>
// 							<ol className="breadcrumb">
// 								<li className="breadcrumb-item"><Link to="/"><i className="fa fa-home"></i> Dashboard</Link></li>
// 								<li className="breadcrumb-item"><Link to="/product"> Product </Link></li>
// 								<li className="breadcrumb-item">Add Product</li>
// 							</ol>
// 						</nav>
// 					</div>
// 				</div>

// 			</div>
// 		</div>
// 		<section className="content">
// 		{/* & submit(e) */}
// 			<form onSubmit={(e) => addinfo(e) } enctype="multipart/form-data">
// 				<div className="row">
// 					<div className="col-lg-12 col-12">
// 						<div className="box">
// 							<div className="box-body">
// 								<h4 className="mt-0 mb-20">Add Product :</h4>
// 								<div className="form-group" enctype="multipart/form-data">
// 									<label> Vendore Name: </label>
// 									<select name="productlist" value={product_vendor} className="form-control" onChange={(e) => setProduct_vendor(e.target.value)} placeholder='Vendor Name' required="Name required">


// 										<option value="Admin"> Admin </option>
// 									</select>
// 								</div>

// 								<div className="form-group">
// 									<div className="form-group">
// 										<label> App Type: </label>
// 										<select name="selectList" value={selectList} className="form-control" onChange={(e) => SetSelectList(e.target.value)} placeholder='App Type' required="required">

// 											<option value="SELL"> Sell </option>
// 											<option value="RENT"> rent </option>

// 										</select>
// 									</div>
									
// 								</div>
// 								{/* <div className="form-group">
// 								<label> Vendore Name:</label>
// 								<input type="text" value={product_vendor} onChange={(e) => setProduct_vendor(e.target.value)} placeholder=' Product_Vendore_Name' className='form-control' required="required" />
// 							</div> */}
// 								{/*<div className="form-group" style={display='none'}>
// 								<label> Vendore id:</label>
// 								<input type="text" value={product_vendor_id} onChange={(e) => SetProduct_vendor_id(e.target.value)} placeholder=' Product_Vendore_Name' className='form-control' required="required" />
// 							</div> */}
// 								<div className="form-group">
// 									<label> Product Name:</label>
// 									<input type="text" value={product_name} onChange={(e) => SetProduct_name(e.target.value)} placeholder=' Product Name' className='form-control' required="required" />
// 								</div>
// 								<div className="form-group">
// 									<label> Product Type:</label>
// 									<select name="selectList" value={ProductType} className="form-control" onChange={(e) => SetProductType(e.target.value)} placeholder='Contact Name' required="required">

// 										<option value={"FEATURE"}> Feature </option>
// 										<option value={"RECOMMENDED"}> Recommended </option>
// 									</select>

// 								</div>
// 								<div className="form-group">
// 									<label> Product Tagline:</label>
// 									<input type="text" value={product_tagline} onChange={(e) => SetProduct_tagline(e.target.value)} placeholder=' Product Tagline' className='form-control' required="required" />
// 								</div>
// 								<div className="form-group">
// 									<label> Product Flat Price: </label>
// 									<input type="number" name="quantity" value={product_flat_price} onChange={(e) => SetProduct_flat_price(e.target.value)} placeholder=' ProductFlate Price' className='form-control' required="required" />
// 								</div>
// 								<div className="form-group">
// 									<label> Product Amount: </label>
// 									<input type="number" name="quantity" value={product_amount} onChange={(e) => SetProduct_amount(e.target.value)} placeholder=' Product Flate Price' className='form-control' required="required" />
// 								</div>
// 								<div className="form-group">
// 									<label> Product Offer:</label>
// 									<input type="text" value={product_offcer} onChange={(e) => SetProduct_offcer(e.target.value)} placeholder=' Product Offer' className='form-control' required="required" />
// 								</div>
// 								<div className="form-group">
// 									<label> Product Deposit:</label>
// 									<input type="number" value={product_despoit} onChange={(e) => SetProduct_despoit(e.target.value)} placeholder=' Product Deposit' className='form-control' required="required" />
// 								</div>
// 								<div className="form-group">
// 									<label> Product Valid Offer:</label>
// 									<input type="text" value={product_valid_offer} onChange={(e) => Setproduct_valid_offer(e.target.value)} placeholder='Product Valid offer' className='form-control' required="required" />
// 								</div>
// 								{/* <div className="form-group">
// 								<label> Product Verified:</label>
// 								<input type="text" value={product_verified} onChange={(e) => SetProduct_verified(e.target.value)} placeholder=' Product Verified' className='form-control' required="required" />
// 							</div> */}
// 								<div className="form-group">
// 									<label> Product Stock Info:</label>
// 									<input type="number" value={product_stock_info} onChange={(e) => Setproduct_stock_info(e.target.value)} placeholder=' Product Stock Info' className='form-control' required="required" />
// 								</div>

// 								<div className="form-group">
// 									<label>Product quantity:</label>
// 									<input type="number" value={product_quantity} onChange={(e) => setProduct_quantity(e.target.value)} placeholder='product quantity' className='form-control' required="required" />
// 								</div>
// 								{/* <div className="form-group">
// 								<label>Product rating:</label>
// 								<input type="text" value={product_rating} onChange={(e) => SetProduct_rating(e.target.value)} placeholder='Product rating' className='form-control' required="required" />
// 							</div> */}

// 								<div className="form-group">
// 									<label> Product Rating:</label>
// 									<select name="selectList" value={product_rating} className="form-control" onChange={(e) => SetProduct_rating(e.target.value)} placeholder='Contact Name' required="required">

// 										<option value={1}> 1 </option>
// 										<option value={1.5}> 1.5 </option>
// 										<option value={2}> 2 </option>
// 										<option value={2.5}> 2.5 </option>
// 										<option value={3}> 3 </option>
// 										<option value={3.5}> 3.5 </option>
// 										<option value={4}> 4 </option>
// 										<option value={4.5}> 4.5 </option>
// 										<option value={5}> 5 </option>
// 									</select>

// 								</div>
// 								{/* <div className="form-group">
// 								<label> Product Total review:</label>
// 								<input type="number" value={product_Total_review} onChange={(e) => SetProduct_Total_review(e.target.value)} placeholder='Product Total review' className='form-control' required="required" />
// 							</div> */}
// 								{/* <div className="form-group">
// 								<label> Product all rating:</label>
// 								<input type="text" value={product_all_rating} onChange={(e) => SetProduct_all_rating(e.target.value)} placeholder='Product all rating' className='form-control' required="required" />
// 							</div> */}
// 								{/* <div className="form-group">
// 								<label> Product Status:</label>
// 								<input   type="text" value={product_Status} onChange={(e) => SetProduct_Status(e.target.value)} placeholder='Product Status' className='form-control' required="required" readonly/>
// 							</div> */}

// 								<div className="form-group">
// 									<label> Description:</label>
// 									<input type="text" value={product_description} onChange={(e) => SetProduct_description(e.target.value)} placeholder='Description' className='form-control' required="required" />
// 								</div>

// 								<div className="form-group">
// 									<label> Cover Image :</label>
// 									<input type="file" value={product_cover_image} onChange={(e) => SetProduct_cover_image(e.target.value)} placeholder='Product cover image' className='form-control' required="required" />
// 								</div>

//                                 {/* <div className="form-group">
// 								<label htmlFor="file">Upload File:</label>								
//                                 <input type="file"  className='form-control' multiple  name='file' onChange={handleFileChange} />
// 								</div>
// 								 */}
								
// 								<div className="form-group">
// 									<label> Slide Image1:</label>
// 									<input type="file" value={product_slide_image1} onChange={(e) => SetProduct_slide_image1(e.target.value)} placeholder='product slide image1' className='form-control' required="required" />
// 								</div>
// 								<div className="form-group">
// 									<label> Slide Image2:</label>
// 									<input type="file" value={product_slide_image2} onChange={(e) => SetProduct_slide_image2(e.target.value)} placeholder='product slide image2' className='form-control' required="required" />
// 								</div>
// 								<div className="form-group">
// 									<label> Slide Image3:</label>
// 									<input type="file" value={product_slide_image3} onChange={(e) => SetProduct_slide_image3(e.target.value)} placeholder='product slide image3' className='form-control' required="required" />
// 								</div>
// 								<div className="form-group">
// 									<label> Slide Image4:</label>
// 									<input type="file" value={product_slide_image4} onChange={(e) => SetProduct_slide_image4(e.target.value)} placeholder='product slide image4' className='form-control' required="required" />
// 								</div>

// 							</div>
// 							<div className="box-footer">
// 								<button className="btn btn-warning" style={{ marginRight: "10px" }}>Reset</button>
// 								<button type="submit" className="btn  btn-primary" >Add Product</button>
// 							</div>
// 							{/* <div >
// 								{ file.filepreview !==null ?
// 									<img className="previewing" src={file.filepreview} alt="UploadImage" />
								
// 								:null
// 								}
// 							</div> */}

// 						</div>
// 					</div>
// 				</div>
// 			</form>
// 		</section>

// 	</>
// }
// export default AddProduct;





















// import React, { useState, useEffect } from 'react'

// const axios = require('axios');




// function AddProduct() {

// 	const [userInfo, setUserInfo] = useState({
// 		file: [],
// 		filepreview: null
// 	});

// 	const handleFileChange = (event) => {
// 		setUserInfo({
// 			...userInfo,
// 			file: event.target.files[0],
// 			filepreview: URL.revokeObjectURL(event.target.files[0]),


// 		})
// 	}

// 	const submit = async () => {
// 		const formData = new FormData();
// 		formData.append('file', userInfo.file);

// 		axios.post("http://34.125.20.72:4260/movetoupload", formData, {
// 			headers: { "Content-Type": "multipart/form-data" }
// 		})
// 			.then(res => {
// 				console.log(res)
// 			})

// 	}







// 	return <>

// 		<section className="content">
			
		
// 				<div>
// 					<input type="file" className='form-control' name='upload_file' onChange={handleFileChange} />
// 					</div>
// 					<div>
// 						<button type='submit' className='btn btn-dark' onClick={()=>submit()}
// 						></button>
// 					</div>
		
			
// 		</section>

// 	</>
// }
// export default AddProduct;




// ####################################################################################Etra old work ######################################################################