

import React, { useState, useEffect } from 'react'
import { Link, useParams } from 'react-router-dom';
import alertify from 'alertifyjs';
import 'alertifyjs/build/css/alertify.css';





function UpdateProduct() {
	const params = useParams();
	const [data, setData] = useState([]);
	// const [productlist, SetProductlist] = useState("");
	const [product_vendor, SetProduct_vendor] = useState("");
	const [selectList, SetSelectList] = useState("");
	if (selectList == 'RENT') {
		$("#ProductDeposit").show()
	}
	else if (selectList == 'SELL') {
		$("#ProductDeposit").hide()
	}

	const [category_id, SetCategory_id] = useState("");
	const [product_name, setProduct_name] = useState("");
	const [ProductType, SetProductType] = useState("");
	const [product_tagline, SetProduct_tagline] = useState("");
	const [product_flat_price, SetProduct_flat_price] = useState("");
	const [product_amount, SetProduct_amount] = useState("");
	const [product_offcer, SetProduct_offcer] = useState("");
	const [product_despoit, SetProduct_despoit] = useState("");
	const [product_valid_offer, Setproduct_valid_offer] = useState("");
	// const [product_verified, SetProduct_verified] = useState("");
	const [product_stock_info, Setproduct_stock_info] = useState("");
	const [product_quantity, setProduct_quantity] = useState("");
	const [product_rating, SetProduct_rating] = useState("");
	// const [product_Total_review, SetProduct_Total_review] = useState("");
	// const [product_all_rating, SetProduct_all_rating] = useState("");
	// const [product_Status, SetProduct_Status] = useState("");
	const [product_description, SetProduct_description] = useState("");
	const [product_cover_image, SetProduct_cover_image] = useState("");
	const [product_slide_image1, SetProduct_slide_image1] = useState("");
	const [product_slide_image2, SetProduct_slide_image2] = useState("");
	const [product_slide_image3, SetProduct_slide_image3] = useState("");
	const [product_slide_image4, SetProduct_slide_image4] = useState("");
	const [id, Setid] = useState("");

	const [category, setCategory] = useState([]);
	// const alldataset = JSON.parse(sessionStorage.getItem('vendore-info'));

	// 	// var Vendore_id = dataVendore.result[0].Vendor.id


	// 	  var vin_id =alldataset.result[0].Vendor.id;
	// console.log("vin_id",vin_id)
	// useEffect(() => {
	// 	getcategory();
	// }, []);

	const getcategory = () => {
		// fetch('http://192.168.1.22:4260/category_list').
		fetch('http://34.125.20.72:4260/category_list').
			then((result) => {
				result.json().
					then((resp) => {
						setCategory(resp.data)
						console.log("", resp.data)
					})
			});

		// $("#lodderGet").css("display", "none");

	}



	const getProduct = async () => {

		let result = await fetch(`http://34.125.20.72:4260/product_list_by_id/${params.id}`);
		result = await result.json();

		console.log("datachech all", result.data[0].Product.product_cover_image)
		// SetProductlist(result.data[0].Product.productlist);
		SetSelectList(result.data[0].Product.selectList);
		if(result.data[0].Product.selectList =='RENT')
{
	$("#ProductDeposit").show()

}
else if(result.data[0].Product.selectList=='SELL')
{
	$("#ProductDeposit").hide()
}
		SetCategory_id(result.data[0].Product.category_id);
		setProduct_name(result.data[0].Product.product_name);
		SetProductType(result.data[0].Product.ProductType);
		SetProduct_tagline(result.data[0].Product.product_tagline);
		SetProduct_flat_price(result.data[0].Product.product_flat_price);
		SetProduct_amount(result.data[0].Product.product_amount);
		SetProduct_offcer(result.data[0].Product.product_offcer);
		SetProduct_despoit(result.data[0].Product.product_despoit);
		Setproduct_valid_offer(result.data[0].Product.product_valid_offer);
		// SetProduct_verified(result.data[0].Product.product_verified);
		Setproduct_stock_info(result.data[0].Product.product_stock_info);
		setProduct_quantity(result.data[0].Product.product_quantity);
		SetProduct_rating(result.data[0].Product.product_rating);
		// SetProduct_Total_review(result.data[0].Product.product_Total_review);
		// SetProduct_all_rating(result.data[0].Product.product_all_rating);
		// SetProduct_Status(result.data[0].Product.product_Status);
		SetProduct_description(result.data[0].Product.product_description);
		Setid(result.data[0].Product.id)
		SetProduct_cover_image(result.data[0].Product.product_cover_image);
		SetProduct_slide_image1(result.data[0].Product.product_slide_image1);
		SetProduct_slide_image2(result.data[0].Product.product_slide_image2);
		SetProduct_slide_image3(result.data[0].Product.product_slide_image3);
		SetProduct_slide_image4(result.data[0].Product.product_slide_image4);
		setData(data)

		SetProduct_vendor(result.data[0].Product.product_vendor);
		$("#lodderGet").css("display", "none");

	};

	useEffect(() => {
		getProduct();
		getcategory();
	}, []);
	async function editProduct() {
		var data = {
			"id": id,
			// "productlist":productlist,
			// "product_vendor_id":vin_id,
			"selectList": selectList,
			"category_id": category_id,
			"product_name": product_name,
			"ProductType": ProductType,
			"product_tagline": product_tagline,
			"product_flat_price": product_flat_price,
			"product_amount": product_amount,
			"product_offcer": product_offcer,
			"product_despoit": product_despoit,
			"product_valid_offer": product_valid_offer,
			// "product_verified":product_verified,
			"product_stock_info": product_stock_info,
			"product_quantity": product_quantity,
			"product_rating": product_rating,
			// "product_Total_review":product_Total_review,
			// "product_all_rating":product_all_rating,
			// "product_Status":product_Status,
			"product_description": product_description,
			"product_cover_image": `https://www.eventneedz.com/static/media/defalt_image.fb6ad4d8.jpg`,
			"product_slide_image1": `https://www.eventneedz.com/static/media/defalt_image.fb6ad4d8.jpg`,
			"product_slide_image2": `https://www.eventneedz.com/static/media/defalt_image.fb6ad4d8.jpg`,
			"product_slide_image3": `https://www.eventneedz.com/static/media/defalt_image.fb6ad4d8.jpg`,
			"product_slide_image4": `https://www.eventneedz.com/static/media/defalt_image.fb6ad4d8.jpg`,
			"product_vendor": product_vendor

		}
		console.log("datata", data);

		fetch('http://34.125.20.72:4260/update_product_admin', {
			method: 'POST',
			headers: {
				"Content-Type": "application/json",
				"Accept": "application/json"
			},
			body: JSON.stringify(data)


		})
			.then((result) => {
				result.json()
				.then((response) => {
					console.warn("respons", response)
					getProduct()
					if (response.status == true) {

						alertify.success('Your Product Successfull Updated ');
					}
				})
			})
	}





	return <>
		<div className="content-header">
			<div className="d-flex align-items-center">
				<div className="mr-auto">
					<div className="d-inline-block align-items-center">
						<nav>
							<ol className="breadcrumb">
								<li className="breadcrumb-item"><Link to="/"><i className="fa fa-home"></i> Dashboard</Link></li>
								<li className="breadcrumb-item"><Link to="/product"> Product </Link></li>
								<li className="breadcrumb-item">Update Product</li>
							</ol>
						</nav>
					</div>
				</div>

			</div>
		</div>
		<section className="content">
			<div className="row">
				<div className="col-lg-12 col-12">
					<div className="box">
						<div className="box-body">
							<h4 className="mt-0 mb-20">Update Product :</h4>
							{/* <div className="form-group" enctype="multipart/form-data">

							<select name="productlist" value={productlist} className="form-control" onChange={(e) => SetProductlist(e.target.value)} placeholder='Contact Name' className='form-control' required ="required">
								<option value={""}> Product For </option>	
								<option value="SELL"> Sell </option>
								<option value="RENT"> rent </option>
								</select>
							</div> */}
							<div className="form-group" enctype="multipart/form-data">
								<label> Vendore Name: </label>
								{/* <select name="productlist" value={product_vendor} className="form-control" onChange={(e) => setProduct_vendor(e.target.value)} placeholder='Contact Name'  required ="required">
							    
								{/* <option value={""}> Select </option>	 
								<option value="Admin"> Admin </option>								
								</select> */}
							</div>

							<div className="form-group">
								<div className="form-group">
									<label> App Type:</label>
									<select name="selectList" value={selectList} className="form-control" onChange={(e) => SetSelectList(e.target.value)} placeholder='Contact Name' required="required">
										{/* <option value={""}> App Type </option> */}
										<option > Select AppType </option>
										<option value="SELL"> Sell </option>
										<option value="RENT"> rent </option>

									</select>
								</div>
								<div className="form-group">
									<label> Category Types:</label>
									<select name="selectList" value={category_id} className="form-control" onChange={(e) => SetCategory_id(e.target.value)} placeholder='Contact Name' required >
										{/* <option value="" id='1'>category </option> */}
										{category && category.map((data, index) => {
											return (

												<option value={index + 1} id='1'>{data.category.name} </option>
											)
										})}

									</select>
								</div>

							</div>
							{/* <div className="form-group">
								<label> Vendore Name:</label>
								<input type="text" value={product_vendor} onChange={(e) => setProduct_vendor(e.target.value)} placeholder=' Product_Vendore_Name' className='form-control' required="required" />
							</div> */}
							{/*<div className="form-group" style={display='none'}>
								<label> Vendore id:</label>
								<input type="text" value={product_vendor_id} onChange={(e) => SetProduct_vendor_id(e.target.value)} placeholder=' Product_Vendore_Name' className='form-control' required="required" />
							</div> */}
							<div className="form-group">
								<label> Product Name:</label>
								<input type="text" value={product_name} onChange={(e) => setProduct_name(e.target.value)} placeholder=' Product_Name' className='form-control' required="required" />
							</div>
							<div className="form-group">
								<label> Product Type:</label>

								<select name="selectList" value={ProductType} onChange={(e) => SetProductType(e.target.value)} placeholder='Contact Name' className='form-control' required="required">
									{/* <option > Select </option> */}
									<option value="FEATURE"> Feature </option>
									<option value="RECOMMENDED"> Recommended </option>
								</select>

							</div>
							<div className="form-group">
								<label> Product Tagline:</label>
								<input type="text" value={product_tagline} onChange={(e) => SetProduct_tagline(e.target.value)} placeholder=' Product Tagline' className='form-control' required="required" />
							</div>
							<div className="form-group">
								<label> Product Flat Price: </label>
								<input type="number" value={product_flat_price} onChange={(e) => SetProduct_flat_price(e.target.value)} placeholder=' ProductFlate Price' className='form-control' required="required" />
							</div>
							<div className="form-group">
								<label> Product Amount: </label>
								<input type="number" value={product_amount} onChange={(e) => SetProduct_amount(e.target.value)} placeholder=' Product Amount' className='form-control' required="required" />
							</div>
							<div className="form-group">
								<label> Product Offer:</label>
								<input type="text" value={product_offcer} onChange={(e) => SetProduct_offcer(e.target.value)} placeholder=' Product Offer' className='form-control'  />
							</div>
							
							<div className="form-group" id= 'ProductDeposit'>
								<label> Product Deposit:</label>
								<input type="text" value={product_despoit} onChange={(e) => SetProduct_despoit(e.target.value)} placeholder=' Product Diposit' className='form-control' required="required" />
							</div>
							<div className="form-group">
								<label> Product Valid Offer:</label>
								<input type="text" value={product_valid_offer} onChange={(e) => Setproduct_valid_offer(e.target.value)} placeholder='Product Valid offer' className='form-control' required="required" />
							</div>
							{/* <div className="form-group">
								<label> Product Verified:</label>
								<input type="text" value={product_verified} onChange={(e) => SetProduct_verified(e.target.value)} placeholder=' Product Verified' className='form-control' required="required" />
							</div> */}
							<div className="form-group">
								<label> Product Stock Info:</label>
								<input type="text" value={product_stock_info} onChange={(e) => Setproduct_stock_info(e.target.value)} placeholder=' Product Stock Info' className='form-control' required="required" />
							</div>

							<div className="form-group">
								<label>Product quantity:</label>
								<input type="text" value={product_quantity} onChange={(e) => setProduct_quantity(e.target.value)} placeholder='product quantity' className='form-control' required="required" />
							</div>
							<div className="form-group">
								<label>Product rating:</label>
								<input type="text" value={product_rating} onChange={(e) => SetProduct_rating(e.target.value)} placeholder='Product rating' className='form-control' required="required" />
							</div>
							{/* <div className="form-group">
								<label> Product Total review:</label>
								<input type="text" value={product_Total_review} onChange={(e) => SetProduct_Total_review(e.target.value)} placeholder='Product Total review' className='form-control' required="required" />
							</div> */}
							{/* <div className="form-group">
								<label> Product all rating:</label>
								<input type="text" value={product_all_rating} onChange={(e) => SetProduct_all_rating(e.target.value)} placeholder='Product all rating' className='form-control' required="required" />
							</div> */}
							{/* <div className="form-group">
								<label> Product Status:</label>
								<input readonly type="text" value={product_Status} onChange={(e) => SetProduct_Status(e.target.value)} placeholder='Product Status' className='form-control' required="required" />
							</div> */}

							<div className="form-group">
								<label> Description:</label>
								<input type="text" value={product_description} onChange={(e) => SetProduct_description(e.target.value)} placeholder='Description' className='form-control' required="required" />
							</div>

							<div className="form-group">
								<label> Cover Image :</label>
								<img width={70} src={product_cover_image} required="required" className="photo" />
								<input type="text" value={product_cover_image} onChange={(e) => SetProduct_cover_image(e.target.value)} placeholder='Product cover image' className='form-control' required="required" />

							</div>
							<div className="form-group">
								<label> Slide Image1:</label>
								<img width={70} src={product_slide_image1} required="required" className="photo" />
								{/* <input type="text" name='image' value={product_slide_image1} onChange={(e) => SetProduct_slide_image1(e.target.value)} placeholder='Seo Name' className='form-control' required="required" /> */}
								<input type="text" name='image' value={product_slide_image1} onChange={(e) => SetProduct_slide_image1(e.target.value)} placeholder='Product Slide Image1' className='form-control' required="required" />

							</div>
							<div className="form-group">
								<label> Slide Image2:</label>
								<img width={70} src={product_slide_image2} required="required" className="photo" />
								<input type="text" value={"product_slide_image2"} onChange={(e) => SetProduct_slide_image2(e.target.value)} placeholder='Product Slide Image2' className='form-control' required="required" />
							</div>
							<div className="form-group">
								<label> Slide Image3:</label>
								<img width={70} src={product_slide_image3} required="required" className="photo" />
								<input type="text" value={product_slide_image3} onChange={(e) => SetProduct_slide_image3(e.target.value)} placeholder='Product Slide Image3' className='form-control' required="required" />
							</div>
							<div className="form-group">
								<label> Slide Image4:</label>
								<img width={70} src={product_slide_image4} required="required" className="photo" />
								<input type="text" value={product_slide_image4} onChange={(e) => SetProduct_slide_image4(e.target.value)} placeholder='Product Slide Image4' className='form-control' required="required" />
							</div>

						</div>
						<div className="box-footer">
							<button type="submit" className="btn btn-warning" style={{ marginRight: "10px" }}>Reset</button>
							<button className="btn  btn-primary" onClick={() => editProduct()}>Update Product</button>
						</div>

					</div>
				</div>
			</div>
		</section>
	</>
}
export default UpdateProduct;
