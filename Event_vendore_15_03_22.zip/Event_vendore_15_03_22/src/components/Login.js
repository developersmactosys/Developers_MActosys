import React, { useEffect, useState } from 'react';
import { useNavigate } from "react-router-dom";
import { useHistory } from "react-router-dom";
import {  BrowserRouter as Router, Route, Redirect} from 'react-router-dom';
import Dashboard from '../components/Home/Home';
import { Navigate } from 'react-router-dom';



function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // const navigate = useNavigate();
  useEffect(() => {
    
    if (localStorage.getItem('vendore-info')) {     
      // history.push("/")
    }
  }, [])
  async function  login(e) {
    e.preventDefault()
    
    // console.warn("data", email, password)
    let item = { email, password }   
   
    let result = await fetch('http://34.125.20.72:4260/vendor_login', {
      method: 'POST',
      headers: {
        "content-Type": "application/json",
        "Accept": "application/json"
        
      },
      
      body: JSON.stringify(item),
      

    });
    
    result = await result.json();   
    // localStorage.setItem('vendore-info', JSON.stringify(result));
    // history.push("/")
    // console.log("dadadadaada",result.status)


    if (result.status == true) {
      

     var datata = sessionStorage.setItem('vendore-info', JSON.stringify(result));
     console.log("hdfs", datata)
    

    //  localStorage.setItem('vendore-info',  JSON.stringify(result));

      const alldatadfsdf = JSON.parse(sessionStorage.getItem('vendore-info'));
      console.log("dataid", alldatadfsdf.result[0].Vendor.vendor_companyName)


      // const cat = localStorage.getItem('vendore-info');
      //  console.log("cat",cat )
      
      
     //  var x = localStorage.getItem("mytime");
     location.href = "/Dashboard";

    }  
    if (result.status == false) { 
     
     
      $(".login-failed").show();
      $("#loading").hide();
      location.href = "/";
    }
  
  }

  return (
    <div className='Login'>
      <div className='Login_inner'>
        {/* <h1>Let's Get Started</h1> */}
        <h4 className="text-center text-dark">Vendor Login With EventNeedz</h4>
      
        <form onSubmit={(e) => login(e) } className="user needs-validation" id="login_form" novalidate>



          <div className="form-group">
            <label for="username">Username:</label>
            <input
              type="text"
              onChange={(e) => setEmail(e.target.value)}
              value={email}
              className="form-control"
              placeholder="Enter username"
              required
            />
             {/* <label for="username">Username:</label>
            <input className="form-control form-control-user"
              type="text" id="username" placeholder="Enter username..."
              Name="username" required></input> */}
          </div>

          <div className="form-group">
            <label for="password">Password:</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="form-control"
              placeholder="Enter password"
              required
            />
            {/* <input className="form-control form-control-user"
              type="password" id="password" placeholder="Password" name="password"
              required></input> */}
          </div>

          <div className='form-group login-failed' style={{display: "none", color: "red"}}>Login
            failed. Please check your Username/password...</div>

          <button className="btn btn-primary btn-block text-white btn-user"
            type="submit">Login</button>

            

        </form>
      </div></div>
  );

}
// (function () {
//   'use strict';
//   window.addEventListener('load', function () {
//     // Fetch all the forms we want to apply custom Bootstrap validation styles to
//     var forms = document.getElementsByClassName('needs-validation');
//     // Loop over them and prevent submission
//     var validation = Array.prototype.filter.call(forms, function (form) {
//       form.addEventListener('submit', function (event) {
//         if (form.checkValidity() === false) {
//           event.preventDefault();
//           event.stopPropagation();
//         }
//         form.classList.add('was-validated');
//       }, false);
//     });
//   }, false);
// })();

// $(document).ready(function () {
//   // var apiHost = "https://www.eventneedz.com/api";
//   // var apiHost = "http://34.125.20.72:4260/vendor_login";

// 	let item = { email, password }
//   let apiHost =  fetch("http://34.125.20.72:4260/vendor_login", {
// 			method: 'POST',
// 			headers: {
// 				"Content-Type": "application/json",
// 				"Accept": "application/json"
// 			},
// 			body: JSON.stringify(item)
// 		})


// 		result = result.json();





//   $('#login_form').submit(function (event) {
//     $("#loading").show();
//     if (this.checkValidity()) {
//       event.preventDefault();

//       axios.get(apiHost + '/', {
//         params: {
//           username: $('#username').val(),
//           password: $('#password').val()
//         }
//       })
//         .then(function (response) {
//           if (response.data && response.data.id) {

//             sessionStorage.setItem('usrses', JSON.stringify(response.data));
//            //  var x = localStorage.getItem("mytime");
//            location.href = "index.html";

//           } else {
//             $(".login-failed").show();
//             $("#loading").hide();
//           }
//         })
//         .catch(function (error) {
//           if (error.response.status == 404) {
//             $(".login-failed").show();
//             $("#loading").hide();
//           }
//         });
//     } else {
//       $("#loading").hide();
//     }
//   });
// });

export default Login;