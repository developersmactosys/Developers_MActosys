// import React, { Component } from 'react';
// import alertify from 'alertifyjs';
// import 'alertifyjs/build/css/alertify.css';
// import { error } from 'jquery';
// class AddUsers extends Component {

// 	constructor() {
// 		super();
// 		this.state = {
// 			firstName: null,
// 			lastName: null,
// 			email: null,
// 			password: null,
// 			mobile: null,
// 			errors:{},
// 			firstName:""
// 		};
// 	}


// 	create() {
//    		let url = 'https://eventneedz.com/api/customers';
// 		fetch(url, {
// 			method: 'post',
// 			headers: {
// 				'Accept': 'application/json',
// 				'Content-Type': 'application/json',
// 			},
// 			body: JSON.stringify(this.state)
// 		}).then((result => {
// 			result.json().then((resp) => {

			
// 				console.warn("myresult", resp.status)

// 				if (resp.status == 'ACTIVE') {
// 					alertify.success('Registration Successful');
// 				}

// 				this.state = 
// 				{
// 					firstName:"",
// 					lastName:""
// 				}
// 			})

			
			
// 		}))


// 	}





// 	render() {

// 		let {errors} = this.state;
// 		return <>
// 		<form className="form">
// 			<section className="content">
// 				<div className="row">
// 					<div className="col-lg-12 col-12">
// 						<div className="box">

						
// 								<div className="box-body">
// 									<h4 className="mt-0 mb-20"> User Info:</h4>
// 									<div className="form-group">
// 										<label>First Name:</label>
// 										<input required type="text"  name='firstName' className="form-control" placeholder="FirstName" onChange={(event) => { this.setState({ firstName: event.target.value }) }} />
// 										{errors.firstName? (<span className='text-dander'>{errors.name}</span>):("")}
// 									</div>
// 									<div className="form-group">
// 										<label>Last Name:</label>
// 										<input type="text" name='lastName' className="form-control" placeholder="LastName" required    onChange={(event) => { this.setState({ lastName: event.target.value }) }} />
// 									</div>
// 									<div className="form-group">
// 										<label>Email address:</label>
// 										<input type="email" name='email' className="form-control" placeholder="Email"   required onChange={(event) => { this.setState({ email: event.target.value }) }} />
// 									</div>
// 									<div className="form-group">
// 										<label>Password:</label>
// 										<input type="password" name='password' className="form-control" placeholder="Password" required onChange={(event) => { this.setState({ password: event.target.value }) }} />
// 									</div>
// 									<div className="form-group">
// 										<label>Confirm Password:</label>
// 										<input type="password" name='password' className="form-control"  placeholder="Password" required onChange={(event) => { this.setState({ password: event.target.value }) }} />
// 									</div>
// 									<div className="form-group">
// 										<label>Contact:</label>
// 										<input type="number" name='mobail' className="form-control"   placeholder="Mobile" required onChange={(event) => { this.setState({ mobile: event.target.value }) }} />
// 									</div>

// 								</div>
// 								<div className="box-footer">
// 									<button type="submit" className="btn btn-danger">Cancel</button>
// 									<button type="submit" onClick={() => { this.create() }} className="btn  btn-success pull-right">Submit</button>
// 								</div>
								

// 						</div>
// 					</div>
// 				</div>
// 			</section>
// 			</form>

// 		</>
// 	}




// }
// export default AddUsers;
