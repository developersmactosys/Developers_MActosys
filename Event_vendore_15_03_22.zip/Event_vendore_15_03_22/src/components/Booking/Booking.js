import React, { useState, useEffect } from "react";
import { Link, useParams } from 'react-router-dom';
// import Spinner from "react-bootstrap/Spinner";

const Product = () => {
  const params = useParams();
  const alldataset = JSON.parse(sessionStorage.getItem('vendore-info'));
  const [data, setData] = useState([]);

  // var product_vendor = alldataset.result[0].Vendor.vendor_name;

  var vin_id = alldataset.result[0].Vendor.id;

  console.log("datataallset", vin_id)
  const getBooking = () => {
    // fetch('http://192.168.1.22:4260/category_list').
    fetch(`http://34.125.20.72:4260/vendor_booking_list/${vin_id}`).
      then((result) => {
        result.json().
          then((resp) => {
            setData(resp.data)
            console.log("datata", resp.data)
          })
      });

    console.log("responseall data", data)

    // $("#lodderGet").css("display", "none");

  }





  //   const params = useParams();  


  //   const [data, setData] = useState([]);
  //   const getBooking =  () => {   
  //     fetch(`http://34.125.20.72:4260/admin_booking_list}`)
  //     .then((result) => {
  //       result.json().then((resp) => {
  //         setData(resp.data);
  //         console.log("response data", resp.data);
  //       });
  //     });

  // $("#lodderGet").css("display", "none");

  //   };
  useEffect(() => {
    getBooking();
  }, []);
  { console.log("datazds", data) }

  if(data){
  return (
    <>
      <div className="content-header">
        <div className="d-flex align-items-center">
          <div className="mr-auto">
            <div className="d-inline-block align-items-center">
              <nav>
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/">
                      <i className="fa fa-home"></i> Dashboard
                    </Link>
                  </li>
                  <li className="breadcrumb-item">Booking </li>
                </ol>
              </nav>
            </div>
          </div>

        </div>
      </div>
      <section className="content">
        <div className="row">
          <div className="col-12">
            <div className="box">
              <div className="box-header with-border">
                <h4 className="box-title" >
                  Booking List{" "}
                  {/* <Spinner
                                        animation="grow"
                                        variant="info"
                                        size="2px"
                                        style={{ display: "block" }}
                                        id="lodderGet"
                                    /> */}
                </h4>
                <div className="box-controls pull-right">
                  <div className="lookup lookup-circle lookup-right">
                    <input type="text" name="s" />
                  </div>
                </div>
              </div>
              <div className="box-body no-padding">
                <div className="table-responsive">
             { console.log("asdsasadd data", data)}
           
                  <table className="table table-hover">
                    <tbody>
                      <tr>
                        <th width="30px">S.NO</th>

                        <th width="100px">Booking Id </th>
                        <th width="100px">Product Name</th>
                        <th width="100px">Quantity</th>
                        <th width="100px">Total Amount</th>
                        <th width="100px">Transaction Id</th>
                        <th width="30px">Status</th>
                        <th width="100px">Date</th>
                       

                      </tr>
                   
                     
                      { data  && data.map((data, index) => {
                        
                    
                        
                       var status_booking=''; 
                       var class_tag='';
                      if(data.Booking.order_status=='NEW' || data.Booking.order_status=='Pending')
                      {
                        status_booking='Pending';
                        var class_tag='badge badge-pill badge-warning';

                      }else if(data.Booking.order_status=='Deliver')
                      {
                        status_booking='Deliver';
                        var class_tag='badge badge-pill badge-success';
                      }
                      else if(data.Booking.order_status=='Reject')
                      {
                        status_booking='Reject';
                        var class_tag='badge badge-pill badge-danger';
                      }
                      else if(data.Booking.order_status=='Approved')
                      {
                        status_booking='Approved';
                        var class_tag='badge badge-pill badge-success';
                      }

                       
                        return (
                          
                          <tr>
                            <td>{index + 1}</td>
                            <td>{data.Booking.order_no ?? "NA"}</td>
                            <td>{data.Booking.product_nam ?? "NA"}</td>
                            <td>{data.Booking.quantity ?? "NA"}</td>
                            <td>{data.Booking.total_amount ?? "NA"}</td>
                            <td>{data.Booking.payment_transaction_id?? "NA"}</td>
                            <td class={class_tag}>{status_booking}</td>
                            <td>{data.Booking.createddate?? "NA"}</td>
                            
                            {/* <td><Link to="#" className='badge badge-pill badge-warning'>
                              <i className='fa fa-eye'></i></Link> <Link to="#" className='badge badge-pill badge-danger'>
                                <i className='fa fa-trash'></i></Link></td> */}

                          </tr>
                          
                        );
                    
                  
                      })}


                    </tbody>
                  </table>




                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
                    }else
                    {
                      return (
                     <>
                      <div className="content-header">
                        <div className="d-flex align-items-center">
                          <div className="mr-auto">
                            <div className="d-inline-block align-items-center">
                              <nav>
                                <ol className="breadcrumb">
                                  <li className="breadcrumb-item">
                                    <Link to="/">
                                      <i className="fa fa-home"></i> Dashboard
                                    </Link>
                                  </li>
                                  <li className="breadcrumb-item">Booking </li>
                                </ol>
                              </nav>
                            </div>
                          </div>
                
                        </div>
                      </div>
                      {/* style={{color: "red"}} */}
                      <h3 style={{textAlign: "center",color: "red",margin:"20%" }}>No Data Found</h3>
                      </>
                      
                      )
                    }
};
export default Product;
