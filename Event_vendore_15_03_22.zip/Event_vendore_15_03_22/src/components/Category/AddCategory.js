import React, { useState } from 'react'
import { Link } from 'react-router-dom';
import alertify from 'alertifyjs';
import 'alertifyjs/build/css/alertify.css';



function AddCategory() {
	const [name, setName] = useState("");	
	const [apptype, SetApptype] = useState("");	
	const [description, SetDescription] = useState("");
	const [image, setImage] = useState("");
	const [image_url, setImage_url] = useState("");

	async function addCategory(e) {

		e.preventDefault()
		let item = { name, apptype, description, image, image_url }
		console.warn(item);
		
			let result = await fetch("http://34.125.20.72:4260/add_category", {
			method: 'POST',
			headers: {
				"Content-Type": "application/json",
				"Accept": "application/json"
			},
			body: JSON.stringify(item)
		})
		result = await result.json();
		console.log("test", result)
		if (result.status == true) {

			alertify.success('Your Category Successfull Added Please wait for verification ');
		}
		console.warn(result);

		setName("");		
		SetDescription("");
		setImage("")		
		SetApptype("")
		setImage_url("")
	


	}
	return <>
		<div className="content-header">
			<div className="d-flex align-items-center">
				<div className="mr-auto">
					<div className="d-inline-block align-items-center">
						<nav>
							<ol className="breadcrumb">
								<li className="breadcrumb-item"><Link to="/"><i className="fa fa-home"></i> Dashboard</Link></li>
								<li className="breadcrumb-item"><Link to="/Category"> Category </Link></li>
								<li className="breadcrumb-item">Add Category</li>
							</ol>
						</nav>
					</div>
				</div>

			</div>
		</div>
		<section className="content">
			<form onSubmit={(e)=>addCategory(e)}>
			<div className="row">
				<div className="col-lg-12 col-12">
					<div className="box">
						<div className="box-body">
							<h4 className="mt-0 mb-20">Add Category :</h4>
							<div className="form-group">
							<label> App Type:</label>
								<select name="apptype" value={apptype} className="form-control" onChange={(e) => SetApptype(e.target.value)} placeholder='Contact Name'  required="All required">
									
									<option value="RENT"> Rent </option>
									<option value="SELL"> Sell </option>
								</select>
							</div>
							<div className="form-group">
								<label> Name:</label>
								<input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder='Category Name' className='form-control' required="Name required" />
							</div>						
							<div className="form-group">
								<label> description:</label>
								<input type="text" value={description} onChange={(e) => SetDescription(e.target.value)} placeholder='Description' className='form-control' required="required" />
							</div>
							<div className="form-group">
								<label> Image:</label>							
								<input type="file" value={image} onChange={(e) => setImage(e.target.value)} placeholder='Image' className='form-control' required="required" />
							</div>
							<div className="form-group">
								<label> Image Url:</label>							
								<input type="file" value={image_url} onChange={(e) => setImage_url(e.target.value)} placeholder='Image' className='form-control' required="required" />
							</div>

						


						</div>
						<div className="box-footer">
							<button  className="btn btn-warning" style={{ marginRight: "10px" }}>Reset</button>
							<button type="submit" className="btn  btn-primary" >Add Category</button>
						</div>

					</div>
				</div>
			</div></form>
		</section>
	</>
}
export default AddCategory;
