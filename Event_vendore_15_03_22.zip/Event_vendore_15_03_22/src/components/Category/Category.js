import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

import Spinner from 'react-bootstrap/Spinner'
import { data } from 'jquery';

const Category = () => {
	const [data, setData] = useState([]);

	const getUsers = () => {
		// fetch('http://192.168.1.22:4260/category_list').
		fetch('http://34.125.20.72:4260/category_list').
			then((result) => {
				result.json().
					then((resp) => {					
						setData(resp.data)	
						console.log("",resp.data)			
					})
			});	

		// $("#lodderGet").css("display", "none");

	}

	useEffect(() => {
		getUsers();
	}, []);

	// function viewOpration(id) {
	// 	alert(id)
	// }
	// function deleteUser(id) {
		
	// 	fetch(`http://34.125.20.72:4260/category_list/${params.id}`,{
	// 		method:'DELETE'
	// 	}).then((result)=>{
	// 		result.json()
	// 		.then((resp)=>{
	// 			console.warm(resp)
	// 			getUsers()
	// 		})
	// 	})
	// }

	return (
		<>
			<div className="content-header">
				<div className="d-flex align-items-center">
					<div className="mr-auto">
						<div className="d-inline-block align-items-center">
							<nav>
								<ol className="breadcrumb">
									<li className="breadcrumb-item"><Link to="/"><i className="fa fa-home"></i> Dashboard</Link></li>
									<li className="breadcrumb-item">Category </li>
								</ol>
							</nav>
						</div>
					</div>
					<Link to="/AddCategory" className='btn btn-primary'> <i class="fa fa-plus-circle"></i> Add Category </Link>
				</div>
			</div>
			<section className="content">
				<div className="row">
					<div className="col-12">
						<div className="box">
							<div className="box-header with-border">
								<h4 className="box-title">Category List <Spinner animation="grow" variant="info" size="2px" style={{ display: "block" }} id="lodderGet" /> </h4>
								<div className="box-controls pull-right">
									<div className="lookup lookup-circle lookup-right">
										<input type="text" name="s" />
									</div>
								</div>
							</div>
							<div className="box-body no-padding">
								<div className="table-responsive">
									<table className="table table-hover">
										<tbody><tr>
											<th>S.NO</th>										
											<th>App Type</th>
										    {/* <th>Description	</th> */}
											<th>Category Name</th>									
											<th>Image</th>												
											<th>Status</th>										
											<th>ACTIONS</th>									

										</tr>
											{
												data.map((data, index) => {
													
													return (
														<tr>
															<td>{index+1}</td>																														
															<td>{data.category.apptype}</td>
															 {/* <td>{data.category.description}</td>  */}
															<td>{data.category.name}</td>
													{/* <td width={100}><img src={data.category.image}  onError={"https://www.eventneedz.com/static/media/defalt_image.fb6ad4d8.jpg"} /></td> */}
															
													<td width={100}><img src={data.category.image} onError={(e)=>{e.target.onerror = null; e.target.src="https://www.eventneedz.com/static/media/defalt_image.fb6ad4d8.jpg"}}/></td>
															{/* <td 															
															width={ 100}><  img src={data.category.image}/></td>*/}
															 <td>{data.category.status}</td> 
															
															
															<td>
																
															{/* <td><Link to={"/CategoryView/"+data.category.id} className='badge badge-pill badge-warning' ><i className='fa fa-eye'></i></Link></td> */}
																<td><Link to={"/UpdateCategory/"+data.category.id} className='badge badge-pill badge-warning' ><i class="fa fa-pencil-square-o" aria-hidden="true"></i></Link></td>
																{/* <td><Link to={"/CategoryView/"+data.Category.id} className='badge badge-pill badge-danger'><i className='fa fa-trash'></i></Link></td> */}
																<td><button className='badge badge-pill badge-danger' ><i className='fa fa-trash'></i></button></td></td>
																{/* onClick={()=>deleteUser(data.category.id)} */}
														</tr>
													)
												})
											}



										</tbody></table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>

		</>

	)
}
export default Category;





