// import React from 'react';
// import { Link } from 'react-router-dom';
// import icon5 from '../../images/front-end-img/courses/1.png';



// function CategoryView () {
//     return <>
   
//       <div className="content-header">
// 			<div className="d-flex align-items-center">
// 				<div className="mr-auto">
// 					<div className="d-inline-block align-items-center">
// 						<nav>
// 							<ol className="breadcrumb">
// 								<li className="breadcrumb-item"><Link to="/"><i className="fa fa-home"></i> Dashboard</Link></li>
// 								<li className="breadcrumb-item"> Category View </li>
// 							</ol>
// 						</nav>
// 					</div>
					
// 				</div>
				
// 			</div>
// 		</div>
//         <section className="content">
// 		  <div className="row">
//           <div className="col-12">
// 			  <div className="box">
//               <div className="box-body">
//     <div className="row">
//         <div className="col-md-4 col-sm-6">
//             <div className="box box-body b-1 text-center no-shadow">
               
//                 <img src={icon5} id="product-image" className="img-fluid" alt="" />
//             </div>
            
//             <div className="clear"></div>
//         </div>
//         <div className="col-md-8 col-sm-6">
//             <h2 className="box-title mt-0">Category Title</h2>
            
//             <h4 className="pro-price mb-0 mt-20">10 Products</h4>
//             <p>Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. but the majority have suffered alteration in some form, by injected humour</p>
            
            
//             <h4 className="box-title mt-20">Key Highlights</h4>
//             <ul className="list-icons">
//                 <li><i className="fa fa-check text-danger float-none"></i> Party Wear</li>
//                 <li><i className="fa fa-check text-danger float-none"></i> Nam libero tempore, cum soluta nobis est</li>
//                 <li><i className="fa fa-check text-danger float-none"></i> Omnis voluptas as placeat facere possimus omnis voluptas.</li>
//             </ul>
//         </div>
//         <div className="col-lg-12 col-md-12 col-sm-12">
//             <h4 className="box-title mt-40">General Info</h4>
//             <div className="table-responsive">
//                 <table className="table">
//                     <tbody>
//                         <tr>
//                             <td width="390">Brand</td>
//                             <td> Brand Name </td>
//                         </tr>
//                         <tr>
//                             <td>Delivery Condition</td>
//                             <td> Lorem Ipsum </td>
//                         </tr>
//                         <tr>
//                             <td>Type</td>
//                             <td> Party Wear </td>
//                         </tr>
//                         <tr>
//                             <td>Style</td>
//                             <td> Modern </td>
//                         </tr>
//                         <tr>
//                             <td>Category Number</td>
//                             <td> FG1548952 </td>
//                         </tr>

//                     </tbody>
//                 </table>
//             </div>
//         </div>
//     </div>
// </div>
// 			  </div>
// 			</div>
//             </div>
//         </section>
       
//     </>
// }
// export default CategoryView;

import React, {useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

import Spinner from 'react-bootstrap/Spinner'
const Category = () => {
	const [users, setUsers] = useState([]);
	const getUsers = async () => {		
		const result = await fetch('http://192.168.1.22:4260/category_list');
		console.log("result",result)
	
		


		setUsers(await result.json());
		$("#lodderGet").css("display", "none");

	}
	 
	useEffect(() => {
		getUsers();
	},[]);
	function viewOpration(id){
			alert(id)
	}
    return (
        <>
		 <div className="content-header">
                <div className="d-flex align-items-center">
                    <div className="mr-auto">
                        <div className="d-inline-block align-items-center">
                            <nav>
                                 <ol className="breadcrumb">
                                    {/* <li className="breadcrumb-item"><Link to="/"><i className="fa fa-home"></i> Dashboard</Link></li> */}
                                    <li className="breadcrumb-item">Category </li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <Link to="/AddCategory" className='btn btn-primary'> <i class="fa fa-plus-circle"></i> Add Category </Link>
                </div>
		</div>
		<section className="content">
		  <div className="row">
          <div className="col-12">
			  <div className="box">
				<div className="box-header with-border">
				  <h4 className="box-title">Category List <Spinner animation="grow"  variant="info" size="2px" style={{ display: "block" }} id="lodderGet" /> </h4>
				  <div className="box-controls pull-right">
					<div className="lookup lookup-circle lookup-right">
					  <input type="text" name="s" />
					</div>
				  </div>
				</div>
				<div className="box-body no-padding">
					<div className="table-responsive">
					  <table className="table table-hover">
						<tbody><tr>
						  <th>ID</th>						
						  <th>Name</th>
						  <th>PHOTO</th>
						  <th>Product</th>
						  <th>Status</th>
                          <th>ACTIONS</th>
                          <th>SELECT TYPE</th>
						  <th>APPTYPE</th>

						</tr>
						{
						users.map((curElem) =>{						
								return(
								<tr>
								    <td>{curElem.id}</td>
									<td>{curElem.name}</td>										
									{/* <td><img src={'https://eventneedz.com'+curElem.image} width={'100px'} alt=''/></td>
									<td>{curElem.OGDescription}</td>
									<td>{curElem.status}</td>
									<td>{curElem.selectList}</td>
									<td>{curElem.apptype}</td> */}
									<td> 
										 <Link to={"/CategoryView/"+curElem.id} className='badge badge-pill badge-warning' ><i className='fa fa-eye'></i></Link>
										<Link to={"/UpdateCategory/"+curElem.id} className='badge badge-pill badge-warning' ><i class="fa fa-pencil-square-o" aria-hidden="true"></i></Link>
										 <Link to={"/CategoryView/"+curElem.id} className='badge badge-pill badge-danger'><i className='fa fa-trash'></i></Link></td>  
								</tr>
								)

							})
						}
						
					  </tbody></table>
					</div>
				</div>
			  </div>
			</div>
            </div>
        </section>
        
    </>

    )
}
export default Category;





